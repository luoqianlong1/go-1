package jwt

import (
	"admin-api/api/entity"
	"admin-api/common/constant"
	"errors"
	"fmt"
	"github.com/dgrijalva/jwt-go"
	"github.com/gin-gonic/gin"
	"time"
)

type userStdClaims struct {
	entity.JwtAdmin
	jwt.StandardClaims
} //定义一个结构体用户申明

// 过期时间设置
const TokenExpireDuration = time.Hour * 24

// 设置时间
// token秘钥
var Secret = []byte("admin-api") // 设置字节切边
var (
	ErrAbsent  = "token absent"  // 令牌不存在
	ErrInvalid = "token invalid" // 令牌无效
)

// GenerateTokenByAdmin 根据用户信息生成token
func GenerateTokenByAdmin(admin entity.SysAdmin) (string, error) { //这玩意是方法码
	var jwtAdmin = entity.JwtAdmin{ //定义一个结构体
		ID:       admin.ID,
		Username: admin.Username,
		Nickname: admin.Nickname,
		Icon:     admin.Icon,
		Email:    admin.Email,
		Phone:    admin.Phone,
		Note:     admin.Note,
	} // admin 对象的信息提取出来，初始化一个 entity.JwtAdmin 对象
	c := userStdClaims{ //这
		jwtAdmin, // 自定义字段
		jwt.StandardClaims{
			ExpiresAt: time.Now().Add(TokenExpireDuration).Unix(), // 过期时间
			Issuer:    "backstage",                                // 签发人
		},
	}
	token := jwt.NewWithClaims(jwt.SigningMethodHS256, c)
	//jwt.NewWithClaims：创建一个新的 JWT 对象，并指定签名方法和声明
	//c是特定的结构体
	// todo set redis
	return token.SignedString(Secret)
}

// ValidateToken 解析JWT Validate有效性
func ValidateToken(tokenString string) (*entity.JwtAdmin, error) {
	//令牌不存在
	//空返回空 输出空
	if tokenString == "" {
		return nil, errors.New(ErrAbsent)
	} //返回错误
	//分析 tokem
	//解析一个 JWT 字符串并返回一个 *Token 对象。

	//令牌为空
	token, err := jwt.Parse(tokenString, func(token *jwt.Token) (interface{}, error) {
		return Secret, nil ///返回密码和错五
	}) //
	// 空 令牌无效. 检查解析后的令牌
	if token == nil {
		return nil, errors.New(ErrInvalid)
	}
	//claim自己定义的结构体
	claims := userStdClaims{}
	//在主函数调用 token clams 结构体看看有没 回调函数返回这个Method 之后就是
	_, err = jwt.ParseWithClaims(tokenString, &claims, func(token *jwt.Token) (interface{}, error) {
		if _, ok := token.Method.(*jwt.SigningMethodHMAC); !ok {
			//类型断言是不是有 *jwtSigningMethodHMAC 字段断言成功后的具体类型变量  返回 欧克 如果有就报错
			return nil, fmt.Errorf("unexpected signing method: %v", token.Header["alg"])
		}
		return Secret, nil //返回密码 和nil 空
	}) //
	//返回的值是：  *jwt.Token：解析后的 jwt.Token 对象。包含了 JWT 的头部、声明和签名信息。
	//error：解析过程中出现的错误信息。如果解析成功，则为 nil。

	if err != nil {
		return nil, err
	}
	return &claims.JwtAdmin, err //返回结构体
}

// GetAdminId 返回id
func GetAdminId(c *gin.Context) (uint, error) {
	// 从 gin.Context 中获取 constant.ContextKeyUserObj 的值
	u, exist := c.Get(constant.ContextKeyUserObj)

	// 如果不存在该值，则返回错误
	if !exist {
		return 0, errors.New("can't get user id")
	}

	// 类型断言，检查 admin是否是 *entity.JwtAdmin 类型
	admin, ok := u.(*entity.JwtAdmin)

	// 如果类型断言成功，返回 admin.ID
	if ok {
		return admin.ID, nil
	}

	// 如果类型断言失败，返回错误
	return 0, errors.New("can't convert to id struct")
}

// GetAdminName 返回用户名
func GetAdminName(c *gin.Context) (string, error) {
	u, exist := c.Get(constant.ContextKeyUserObj)
	if !exist {
		return "", errors.New("can't get user name")
	}
	admin, ok := u.(*entity.JwtAdmin)
	if ok {
		return admin.Username, nil
	}
	return "", errors.New("can't convert to api name")
}

// GetAdmin 返回admin信息
func GetAdmin(c *gin.Context) (*entity.JwtAdmin, error) {
	u, exist := c.Get(constant.ContextKeyUserObj)
	if !exist {
		return nil, errors.New("can't get api")
	}
	admin, ok := u.(*entity.JwtAdmin)
	if ok {
		return admin, nil
	}
	return nil, errors.New("can't convert to api struct")
}
