package db

import (
	"admin-api/common/config" // 引入配置包
	"fmt"                     // 引入格式化输出包
	"gorm.io/driver/mysql"    // 引入MySQL驱动
	"gorm.io/gorm"            // 引入GORM库
	"gorm.io/gorm/logger"     // 引入GORM日志包
)

var Db *gorm.DB // 定义一个GORM的DB变量，用于持有数据库连接。使用指针以避免不必要的拷贝。

func SetupDbLink() error { // SetupDbLink函数用于初始化数据库连接，如果失败则返回错误。
	var err error                   // 定义一个变量用于捕获错误。
	var dbConfig = config.Config.Db // 从全局配置中获取数据库配置。
	//调用函数中的Db的配置
	// 从url写入数据库配置
	url := fmt.Sprintf("%s:%s@tcp(%s:%d)/%s?charset=%s&parseTime=True&loc=Local",
		dbConfig.Username, // 数据库用户名。
		dbConfig.Password, // 数据库密码。
		dbConfig.Host,     // 数据库服务器主机。
		dbConfig.Port,     // 数据库服务器端口。
		dbConfig.Db,       // 数据库名称。
		dbConfig.Charset) // 使用的字符集。

	// 使用GORM打开一个新的数据库连接。
	Db, err = gorm.Open(mysql.Open(url), &gorm.Config{
		Logger:                                   logger.Default.LogMode(logger.Info), // 启用详细的GORM日志记录。
		DisableForeignKeyConstraintWhenMigrating: true,                                // 禁用迁移时的外键约束。
	})
	if err != nil {
		return err // 如果连接失败，返回错误。
	}
	if Db.Error != nil {
		panic(Db.Error) // 如果数据库操作错误，抛出错误。
	}
	sqlDB, err := Db.DB() // 获取底层的sql.DB对象。
	if err != nil {
		return err // 如果获取底层对象失败，返回错误。
	}
	sqlDB.SetMaxIdleConns(dbConfig.MaxIdle) // 设置连接池的最大空闲连接数。
	sqlDB.SetMaxOpenConns(dbConfig.MaxOpen) // 设置连接池的最大打开连接数。
	return nil                              // 返回nil表示成功。
}
