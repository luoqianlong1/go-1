// log/log.go

// log日志
// author: luo
package log

import (
	"admin-api/common/config"                           // 导入通用配置
	rotatelogs "github.com/lestrrat-go/file-rotatelogs" // 用于日志文件的滚动
	"github.com/rifflock/lfshook"                       // 用于日志钩子
	"github.com/sirupsen/logrus"                        // 用于日志记录
	"os"
	"path/filepath"
	"time"
)

var log *logrus.Logger       // 控制台日志对象 这是什么用来干什么的
var logToFile *logrus.Logger // 文件日志对象

// 用途：这是一个全局变量，用于在程序中记录和输出日志信息到控制台。
// 作用：在程序运行时，可以通过这个变量来记录各种日志信息，比如调试信息、错误信息等，并显示在控制台上。这样，开发人员可以在开发和调试程序时，方便地查看程序的运行状态和错误信息。
// 日志文件名
var loggerFile string

// 设置日志文件路径
func setLogFile(file string) {
	loggerFile = file
}

// 初始化函数，设置日志文件路径
func init() {
	// 组合日志文件路径和名称
	setLogFile(filepath.Join(config.Config.Log.Path, config.Config.Log.Name)) //什么用法
	//应用上面的函数赋值给loggerFilestring
}

/* Log 方法根据配置返回适当的日志实例、
log  if  config.Config.Log.Model == "file" log file
else log
if logfile=nil 新建一个logfle
都写入log中*/

func Log() *logrus.Logger {
	// 如果配置为文件输出模式
	if config.Config.Log.Model == "file" {
		return logFile() // 返回文件日志对象
	} else {
		// 如果配置为控制台输出模式
		if log == nil { // 如果log对象未初始化
			log = logrus.New()                                                            // 新建一个logrus.Logger对象
			log.Out = os.Stdout                                                           // 设置输出到标准输出（控制台）
			log.Formatter = &logrus.JSONFormatter{TimestampFormat: "2006-01-02 15:04:05"} // 设置日志格式为JSON格式，并设置时间戳格式
			log.SetLevel(logrus.DebugLevel)                                               // 设置日志级别为Debug
		}
	}
	return log // 在控制台输出我文件
}

// 日志方法，配置并返回文件日志对象
func logFile() *logrus.Logger {
	if logToFile == nil { // 如果logToFile对象未初始化
		logToFile = logrus.New()              // 新建一个logrus.Logger对象
		logToFile.SetLevel(logrus.DebugLevel) // 设置日志级别为Debug

		// 创建日志文件写入器
		logWriter, _ := rotatelogs.New(
			// 分割后的文件名称
			loggerFile+"_%Y%m%d.log",
			// 设置最大保存时间为30天
			rotatelogs.WithMaxAge(30*24*time.Hour),
			// 设置日志切割时间间隔为1天
			rotatelogs.WithRotationTime(24*time.Hour),
		)

		// 创建一个写入映射，将不同级别的日志写入相同的日志分割对象
		writeMap := lfshook.WriterMap{
			logrus.InfoLevel:  logWriter, // Info级别日志写入
			logrus.FatalLevel: logWriter, // Fatal级别日志写入
			logrus.DebugLevel: logWriter, // Debug级别日志写入
			logrus.WarnLevel:  logWriter, // Warn级别日志写入
			logrus.ErrorLevel: logWriter, // Error级别日志写入
			logrus.PanicLevel: logWriter, // Panic级别日志写入
		}

		// 设置日志格式，并创建一个新的钩子
		lfHook := lfshook.NewHook(writeMap, &logrus.JSONFormatter{
			TimestampFormat: "2006-01-02 15:04:05", // 设置时间戳格式
		})

		// 为日志记录器添加钩子
		logToFile.AddHook(lfHook)
	}
	return logToFile // 返回文件日志对象
}
