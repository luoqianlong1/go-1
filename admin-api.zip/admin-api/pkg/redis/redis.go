// Package redis 初始化链接
package redis

import (
	"admin-api/common/config"      // 引入配置包，用于读取 Redis 配置信息
	"context"                      // 引入 context 包，用于控制 Redis 请求的上下文
	"fmt"                          // 引入 fmt 包，用于格式化输出
	"github.com/go-redis/redis/v8" // 引入 go-redis 包，用于 Redis 操作
	"log"                          // 引入 log 包，用于日志记录
)

// RedisDb 声明一个全局变量 RedisDb，用于持有 Redis 客户端实例
var (
	RedisDb *redis.Client // RedisDb 建立一个 Redis 客户端
)

// SetupRedisDb 初始化 Redis 配置并建立连接
func SetupRedisDb() error {
	// 创建一个上下文对象 ctx
	var ctx = context.Background()

	// 使用配置文件中的 Redis 连接信息创建一个新的 Redis 客户端实例
	RedisDb = redis.NewClient(&redis.Options{
		Addr:     config.Config.Redis.Address,  // 从配置文件读取 Redis 地址
		Password: config.Config.Redis.Password, // 从配置文件读取 Redis 密码
		DB:       9,                            // 使用 Redis 的第 9 个数据库
	})

	// 输出 Redis 地址和密码到日志
	log.Printf("redis address: %v\n", config.Config.Redis.Address)
	log.Printf("redis 密码: %v\n", config.Config.Redis.Password)

	// 通过 PING 命令检查与 Redis 服务器的连接是否正常
	_, err := RedisDb.Ping(ctx).Result()
	if err != nil {
		// 如果连接失败，输出错误信息并返回错误
		fmt.Printf("Failed to connect to Redis: %v", err)
		return err
	}

	// 如果连接成功，输出成功信息
	fmt.Println("Successfully connected to Redis")
	return nil
}
