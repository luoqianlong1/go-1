package main

import (
	"admin-api/common/config"
	_ "admin-api/docs"
	"admin-api/pkg/db"
	"admin-api/pkg/log"
	"admin-api/pkg/redis"
	"admin-api/router"
	"context"
	"github.com/gin-gonic/gin"
	"net/http"
	"os"
	"os/signal"
	"time"
)

// @title 通用后台管理系统
// @version 1.0
// @description 后台管理系统API接口文档
// @securityDefinitions.apikey ApiKeyAuth
// @in headecr
// @name Authorization
func main() {
	// 加载日志log
	logger := log.Log()

	// 设置启动模式
	gin.SetMode(config.Config.Server.Model)

	// 初始化数据库和Redis连接
	initConnections()

	// 初始化路由
	router := router.InitRouter()

	// 创建HTTP服务器
	srv := &http.Server{
		Addr:    config.Config.Server.Address,
		Handler: router,
	} //这是什么

	// 启动服务
	go func() {
		//if err := srv.ListenAndServe();：调用 ListenAndServe 方法，并将可能返回的错误赋值给 err。
		//http.ErrServerClosed：这是一个特殊的错误，表示服务器已经关闭，但这是一个预期的行为（例如，通过调用 srv.Shutdown 关闭服务器时会返回这个错误）。
		//err如果正常关闭 就不会输出错误
		if err := srv.ListenAndServe(); err != nil && err != http.ErrServerClosed {
			logger.Info("listen: %s \n", err)
		}
		logger.Info("listen: %s \n", config.Config.Server.Address)
	}() //这是什么

	// 监听关闭信号
	quit := make(chan os.Signal)
	//建立管道  os.Signal类型的
	signal.Notify(quit, os.Interrupt) //吧操作系统的Interrupr 给quit
	<-quit
	//从 quit 通道接收信号。
	//这行代码会阻塞，直到 quit 通道接收到信号。
	//当接收到中   断信号（Ctrl+C）时，程序将继续执行后续代码，
	logger.Info("Shutdown Server ...")

	// 优雅关闭服务器，等待5秒
	//设置超时控制的 操作环境上下问   5秒后执行
	//	defer 关键字用于在函数结束时自动调用 cancel
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)

	defer cancel()
	//在main函数结束时调用取消函数，释放资源
	//如果err 有错误；来大一道logger中
	//如果 err 是 srv也就是HTTP服务器的·
	if err := srv.Shutdown(ctx); err != nil {
		logger.Info("Server Shutdown:", err)
	} //srv.Shutdown(ctx) 尝试在上下文 ctx 的超时时间内（5 秒）关闭服务器。
	//如果在 ctx 超时之前完成关闭操作，srv.Shutdown(ctx) 返回 nil。
	//如果 ctx 超时或者关闭过程中发生错误，srv.Shutdown(ctx) 返回一个错误，并记录到日志中。

	logger.Info("Server exiting")
	//logger打印 服务退出
}

// 初始化连接
func initConnections() {
	// 初始化数据库连接
	db.SetupDbLink()
	// 初始化Redis连接
	redis.SetupRedisDb()
}
