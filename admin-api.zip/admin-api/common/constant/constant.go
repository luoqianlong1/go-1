package constant

// 系统常量定义
// 作者: luo

const (
	// ContextKeyUserObj 用于在上下文中存储已认证的用户对象的键
	//LOGIN_CODE 用作 Redis 键的前缀，以区分不同类型的数据。通过使用前缀，可以避免不同类型的数据之间的键冲突
	LOGIN_CODE        = "login_code:"
	ContextKeyUserObj = "authedUserObj"
)

//后端响应过程中的作用
//在一个典型的后端 Web 应用中，ContextKeyUserObj 会在以下几个关键步骤中发挥作用：
//
//接收请求：
//
//当服务器接收到一个 HTTP 请求时，首先会进入一些中间件进行预处理，如身份验证。
//身份验证中间件：
//
//中间件会验证请求的身份信息（例如 JWT 令牌、API 密钥等）。
//如果验证成功，中间件会将用户信息存储在请求的上下文中，使用 ContextKeyUserObj 作为键。
//处理请求：
//
//经过身份验证后，请求会被传递给实际的处理程序（handler）。
//在处理程序中，可以从上下文中获取用户信息，进行进一步的逻辑处理。
//生成响应：
//
//根据处理结果，生成相应的响应并返回给客户端。
