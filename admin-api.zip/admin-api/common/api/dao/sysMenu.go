// 菜单数据层
// author xiaoluo
package dao

import (
	"admin-api/api/entity"
	"admin-api/common/util"
	. "admin-api/pkg/db"
	"time"
)

// Get System Menu By Name 根据菜单名称查询
func GetSysMenuByName(menuName string) (sysMenu entity.SysMenu) {
	Db.Where("menu_name = ?", menuName).First(&sysMenu)
	return sysMenu
}

// Query System Menu Value Object List 查询新增选项列表
func QuerySysMenuVoList() (sysMenuVo []entity.SysMenuVo) {
	Db.Table("sys_menu").Select("id, menu_name AS label, parent_id").Scan(&sysMenuVo)
	return sysMenuVo
}

// CreateSysMenu 新增菜单
func CreateSysMenu(addSysMenu entity.SysMenu) bool {
	sysMenuByName := GetSysMenuByName(addSysMenu.MenuName)
	if sysMenuByName.ID != 0 {
		return false
	}

	var sysMenu entity.SysMenu
	if addSysMenu.MenuType == 1 { // 目录
		sysMenu = entity.SysMenu{
			ParentId:   0,
			MenuName:   addSysMenu.MenuName,
			Icon:       addSysMenu.Icon,
			MenuType:   addSysMenu.MenuType,
			Url:        addSysMenu.Url,
			MenuStatus: addSysMenu.MenuStatus,
			Sort:       addSysMenu.Sort,
			CreateTime: util.HTime{Time: time.Now()},
		}
	} else { // 菜单或按钮
		sysMenu = entity.SysMenu{
			ParentId:   addSysMenu.ParentId,
			MenuName:   addSysMenu.MenuName,
			Icon:       addSysMenu.Icon,
			MenuType:   addSysMenu.MenuType,
			MenuStatus: addSysMenu.MenuStatus,
			Value:      addSysMenu.Value,
			Url:        addSysMenu.Url,
			Sort:       addSysMenu.Sort,
			CreateTime: util.HTime{Time: time.Now()},
		}
	}

	Db.Create(&sysMenu)
	return true
}

// CreateSysMenu 根据id查询菜单详情
func GetSysMenu(Id int) (sysMenu entity.SysMenu) {
	Db.First(&sysMenu, Id)
	return sysMenu
}

// Update System Men 修改菜单
func UpdateSysMenu(menu entity.SysMenu) (sysMenu entity.SysMenu) {
	Db.First(&sysMenu, menu.ID)
	sysMenu.ParentId = menu.ParentId
	sysMenu.MenuName = menu.MenuName
	sysMenu.Icon = menu.Icon
	sysMenu.Value = menu.Value
	sysMenu.MenuType = menu.MenuType
	sysMenu.Url = menu.Url
	sysMenu.MenuStatus = menu.MenuStatus
	sysMenu.Sort = menu.Sort
	Db.Save(&sysMenu)
	return sysMenu
}

// Get System Menu 获取角色菜单关系
func GetSysRoleMenu(id int) (sysRoleMenu entity.SysRoleMenu) {
	Db.Where("menu_id = ?", id).First(&sysRoleMenu)
	return sysRoleMenu
}

// Delete System Menu 删除菜单
func DeleteSysMenu(dto entity.SysMenuIdDto) bool {
	sysRoleMenu := GetSysRoleMenu(int(dto.Id))
	if sysRoleMenu.MenuId > 0 {
		return false
	}

	Db.Where("parent_id = ?", dto.Id).Delete(&entity.SysMenu{})
	Db.Delete(&entity.SysMenu{}, dto.Id)
	return true
}

// GetSysMenuList 查询菜单列表
func GetSysMenuList(MenuName string, MenuStatus string) (sysMenu []*entity.SysMenu) {
	curDb := Db.Table("sys_menu").Order("sort")
	if MenuName != "" {
		curDb = curDb.Where("menu_name = ?", MenuName)
	}
	if MenuStatus != "" {
		curDb = curDb.Where("menu_status = ?", MenuStatus)
	}
	curDb.Find(&sysMenu)
	return sysMenu
}

// 当前登录用户左侧菜单级列表————————————————————————————————————————————————————————————————————————————————————————————————————————

// 当前登录用户左侧菜单级列表
// 根据 AdminId 和 MenuId 查询用户有权限访问的子菜单
func QueryMenuVoList(AdminId, MenuId uint) (menuSvo []entity.MenuSvo) {
	const status, menuStatus, menuType uint = 1, 2, 2

	// 使用 GORM 构建查询
	Db.Table("sys_menu sm").
		Select("sm.menu_name, sm.icon, sm.url").                      // 选择需要的字段
		Joins("LEFT JOIN sys_role_menu srm ON sm.id = srm.menu_id").  // 连接 sys_role_menu 表
		Joins("LEFT JOIN sys_role sr ON sr.id = srm.role_id").        // 连接 sys_role 表
		Joins("LEFT JOIN sys_admin_role sar ON sar.role_id = sr.id"). // 连接 sys_admin_role 表
		Joins("LEFT JOIN sys_admin sa ON sa.id = sar.admin_id").      // 连接 sys_admin 表
		Where("sr.status = ?", status).                               // 角色状态为有效
		Where("sm.menu_status = ?", menuStatus).                      // 菜单状态为有效
		Where("sm.menu_type = ?", menuType).                          // 菜单类型为子菜单
		Where("sm.parent_id = ?", MenuId).                            // 父菜单 ID
		Where("sa.id = ?", AdminId).                                  // 管理员 ID
		Order("sm.sort").                                             // 排序
		Scan(&menuSvo)                                                // 扫描结果到 menuSvo 切片

	return menuSvo
}

// 当前登录用户左侧菜单列表
// 根据用户 ID 查询用户有权限访问的顶级菜单
func QueryLeftMenuList(Id uint) (leftMenuVo []entity.LeftMenuVo) {
	const status, menuStatus, menuType uint = 1, 2, 1

	// 使用 GORM 构建查询
	Db.Table("sys_menu sm").
		Select("sm.id, sm.menu_name, sm.url, sm.icon").               // 选择需要的字段
		Joins("LEFT JOIN sys_role_menu srm ON sm.id = srm.menu_id").  // 连接 sys_role_menu 表
		Joins("LEFT JOIN sys_role sr ON sr.id = srm.role_id").        // 连接 sys_role 表
		Joins("LEFT JOIN sys_admin_role sar ON sar.role_id = sr.id"). // 连接 sys_admin_role 表
		Joins("LEFT JOIN sys_admin sa ON sa.id = sar.admin_id").      // 连接 sys_admin 表
		Where("sr.status = ?", status).                               // 角色状态为有效
		Where("sm.menu_status = ?", menuStatus).                      // 菜单状态为有效
		Where("sm.menu_type = ?", menuType).                          // 菜单类型为顶级菜单
		Where("sa.id = ?", Id).                                       // 管理员 ID
		Order("sm.sort").                                             // 排序
		Scan(&leftMenuVo)                                             // 扫描结果到 leftMenuVo 切片

	return leftMenuVo
}

// 当前登录用户权限列表
// 根据用户 ID 查询用户拥有的权限
func QueryPermissionList(Id uint) (valueVo []entity.ValueVo) {
	const status, menuStatus, menuType uint = 1, 2, 1

	// 使用 GORM 构建查询
	Db.Table("sys_menu sm").
		Select("sm.value").                                           // 选择需要的字段
		Joins("LEFT JOIN sys_role_menu srm ON sm.id = srm.menu_id").  // 连接 sys_role_menu 表
		Joins("LEFT JOIN sys_role sr ON sr.id = srm.role_id").        // 连接 sys_role 表
		Joins("LEFT JOIN sys_admin_role sar ON sar.role_id = sr.id"). // 连接 sys_admin_role 表
		Joins("LEFT JOIN sys_admin sa ON sa.id = sar.admin_id").      // 连接 sys_admin 表
		Where("sr.status = ?", status).                               // 角色状态为有效
		Where("sm.menu_status = ?", menuStatus).                      // 菜单状态为有效
		Not("sm.menu_type = ?", menuType).                            // 排除顶级菜单
		Where("sa.id = ?", Id).                                       // 管理员 ID
		Scan(&valueVo)                                                // 扫描结果到 valueVo 切片

	return valueVo
}
