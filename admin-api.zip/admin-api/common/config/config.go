// Package config 文件配置
// author: 骆乾龙
// 解析 YAML 配置文件到 Go 语言的结构体
package config

import (
	"fmt"
	"gopkg.in/yaml.v2"
	"io/ioutil"
)

// 总配置文件结构体
// 配置文件 结构体 跟yaml文件里面的相对应
type config struct {
	Server        server        `yaml:"server"`
	Db            db            `yaml:"db"` // 修改为正确的 YAML 标签
	Redis         redis         `yaml:"redis"`
	ImageSettings imageSettings `yaml:"imageSettings"`
	Log           log           `yaml:"log"`
}

// 端口及初始化配置
// //address 端口地址  model模式
type server struct {
	Address string `yaml:"address"`
	Model   string `yaml:"model"`
}

// 数据库配置
type db struct {
	Dialect  string `yaml:"dialect"` //
	Host     string `yaml:"host"`
	Port     int    `yaml:"port"`
	Db       string `yaml:"db"`
	Username string `yaml:"username"`
	Password string `yaml:"password"`
	Charset  string `yaml:"charset"`
	MaxIdle  int    `yaml:"maxIdle"`
	MaxOpen  int    `yaml:"maxOpen"`
}

// Redis 配置
type redis struct {
	Address  string `yaml:"address"` // 修改为 string 类型，通常 Redis 地址是一个字符串
	Password string `yaml:"password"`
}

// 图片配置
// uploadDIr上传地址   ImageHost本地ip地址，用于访问图片
type imageSettings struct {
	UploadDir string `yaml:"uploadDir"`
	ImageHost string `yaml:"imageHost"`
}

// 日志配置
// path 日志文件存放路径 name日志文件名称前缀b file file表示输出到文件
type log struct {
	Path  string `yaml:"path"`
	Name  string `yaml:"name"`
	Model string `yaml:"model"`
}

var Config *config

func init() {
	// 读取 YAML 配置文件 逆向整理
	yamlFile, err := ioutil.ReadFile("./config.yaml")
	if err != nil {
		panic(fmt.Sprintf("Error reading YAML file: %v", err))
	}

	// 解析 YAML 文件到结构体
	Config = &config{} // 初始化 Config
	err = yaml.Unmarshal(yamlFile, Config)
	//b把yamlFile的文件都对应到 Config结构体元素中去
	if err != nil {
		panic(fmt.Sprintf("Error unmarshalling YAML file: %v", err))
	}
}
