// os和browser工具类
package util

import (
	"github.com/gin-gonic/gin"                  // 引入gin框架
	useragent "github.com/wenlng/go-user-agent" // 引入go-user-agent包，用于解析User-Agent字符串
) //useragent是什么哪个IP地址

// Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36
// GetOs 获取操作系统名称
func GetOs(c *gin.Context) string {
	userAgent := c.Request.Header.Get("User-Agent") // 获取User-Agent头信息
	os := useragent.GetOsName(userAgent)            // 解析操作系统名称
	return os                                       // 返回操作系统名称
}

// GetBrowser 获取浏览器名称
func GetBrowser(c *gin.Context) string {
	userAgent := c.Request.Header.Get("User-Agent") // 获取User-Agent头信息
	browser := useragent.GetBrowserName(userAgent)  // 解析浏览器名称
	return browser                                  // 返回浏览器名称
}
