// ip工具类
package util

import (
	"fmt"                                  // 引入fmt包用于格式化输出
	"github.com/gogf/gf/encoding/gcharset" // 引入gcharset包用于字符编码转换
	"github.com/gogf/gf/encoding/gjson"    // 引入gjson包用于JSON解析
	"github.com/gogf/gf/net/ghttp"         // 引入ghttp包用于HTTP请求
	"github.com/gogf/gf/util/gconv"        // 引入gconv包用于类型转换
	"net"                                  // 引入net包用于网络相关操作
	"strings"                              // 引入strings包用于字符串操作
)

// GetRealAddressByIP 获取IP地址的实际地理位置
func GetRealAddressByIP(ip string) string {
	toByteIp := ipToByte(ip) // 将IP地址字符串转换为字节数组
	if isLocalIp(toByteIp) { // 如果是本地IP
		return "服务器登录" // 返回"服务器登录"
	}
	if isLANIp(toByteIp) { // 如果是局域网IP
		return "局域网" // 返回"局域网"
	}
	return getLocation(ip) // 获取外部IP的地理位置并返回
}

// ipToByte 将IP地址字符串转换为字节数组
func ipToByte(ipstr string) []byte {
	ips := strings.Split(ipstr, ".") // 将IP地址字符串按"."分割
	ip := make([]byte, 0, len(ips))  // 创建字节数组
	for _, s := range ips {          // 遍历分割后的字符串
		u := gconv.Uint8(s) // 将字符串转换为uint8类型
		ip = append(ip, u)  // 将转换后的值添加到字节数组中
	}
	return ip // 返回字节数组
}

// isLocalIp 判断是否为本地IP地址
func isLocalIp(IP net.IP) bool {
	if IP.IsLoopback() || IP.IsLinkLocalMulticast() || IP.IsLinkLocalUnicast() { // 判断是否为回环地址、链路本地多播或单播地址
		return true // 是则返回true
	}
	return false // 否则返回false
}

// isLANIp 判断是否为局域网IP地址
func isLANIp(IP net.IP) bool {
	to4 := IP.To4()                  // 获取IPv4格式的IP地址
	fmt.Println(to4)                 // 打印IP地址
	if ip4 := IP.To4(); ip4 != nil { // 如果IP地址为IPv4格式
		switch true { // 进行条件判断
		case ip4[0] == 10: // 10.0.0.0/8
			return true
		case ip4[0] == 172 && ip4[1] >= 16 && ip4[1] <= 31: // 172.16.0.0/12
			return true
		case ip4[0] == 192 && ip4[1] == 168: // 192.168.0.0/16
			return true
		default:
			return false
		}
	}
	return false // 不是IPv4格式则返回false
}

// getLocation 获取外部IP的地理位置
func getLocation(ip string) string {
	url := "https://whois.pconline.com.cn/ipJson.jsp?json=true&ip=" + ip // 将url和ip进行拼接请求URL
	bytes := ghttp.GetBytes(url)                                         //访问服务器                                    // 发送GET请求获取字节数组响应
	src := string(bytes)                                                 // 将字节数组转换为字符串
	srcCharset := "GBK"                                                  //定义string "GBK"                                                  //这个是哪里的用法                                   // 定义源字符集为GBK
	tmp, _ := gcharset.ToUTF8(srcCharset, src)                           // 将字符串从GBK转换为UTF-8
	json, err := gjson.DecodeToJson(tmp)                                 //这个又是什么函转换成json格式           // 将字符串解析为JSON对象
	if err != nil {                                                      // 如果解析出错
		fmt.Println() // 打印空行
	}
	if json.GetInt("code") == 0 { // 如果返回的JSON对象中code字段为0
		addr := json.GetString("addr") // 获取addr字段的值
		return addr                    // 返回地理位置
	} else {
		return "未知地址" // 返回"未知地址"
	}
}

// GetLocalIP 获取本地IP地址
func GetLocalIP() (ip string, err error) {
	addrs, err := net.InterfaceAddrs() // 获取所有网络接口的地址  127.0.0.1/8  192.168.1.5/24
	if err != nil {                    // 如果获取地址出错
		return // 返回错误
	}
	for _, addr := range addrs { // 遍历地址列表
		ipAddr, ok := addr.(*net.IPNet) // 将地址转换为IPNet类型
		if !ok {                        // 如果转换不成功
			continue // 跳过当前地址
		}
		if ipAddr.IP.IsLoopback() { // 如果是回环地址
			continue // 跳过当前地址
		}
		if !ipAddr.IP.IsGlobalUnicast() { // 如果不是全局单播地址
			continue // 跳过当前地址
		}
		return ipAddr.IP.String(), nil // 返回IP地址字符串
	}
	return // 返回空字符串和nil
}
