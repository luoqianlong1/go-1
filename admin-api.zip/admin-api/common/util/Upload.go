// 图片上传工具类
// author
package util

import (
	"os"
)

// CreateDir 创建目录
func CreateDir(filePath string) error {
	if !IsExist(filePath) {
		err := os.MkdirAll(filePath, os.ModePerm)
		//这一行代码使用 Go 语言中的 os.MkdirAll 函数递归地创建目录。它将尝试在给定的 filePath 路径上创建目录及其所有必要的父目录，并使用 os.ModePerm 设置目录的权限。os.ModePerm 是一个常量，代表 0777 的 Unix 权限模式，这意味着目录将被赋予读、写、执行的全部权限。如果目录创建成功，返回 nil，否则返回错误信息。
		if err != nil {
			return err
		}
	}
	return nil
}

// IsExist 判断是否存在
func IsExist(path string) bool {
	_, err := os.Stat(path)
	return !os.IsNotExist(err)
}
