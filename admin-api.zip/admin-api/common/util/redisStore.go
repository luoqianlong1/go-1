// Package component redis存取验配置
// @author 小骆
package util

import (
	"admin-api/common/constant"
	"admin-api/pkg/redis"
	"context"
	"fmt"
	"log"
	"time"
)

// 定义一个空白的上下文
var ctx = context.Background()

// RedisStore 结构体 Get Set
type RedisStore struct{}

// Set 存验证码
func (r RedisStore) Set(id string, value string) {
	key := constant.LOGIN_CODE + id
	//使用 constant.LOGIN_CODE 和 id 生成 Redis 键 key。
	err := redis.RedisDb.Set(ctx, key, value, time.Minute*5).Err()
	//如果有错误打印输出err
	if err != nil {
		log.Println(err.Error())
	}
}

// Get 获取验证码
func (r RedisStore) Get(id string, clear bool) string {
	key := constant.LOGIN_CODE + id //key生成key
	val, err := redis.RedisDb.Get(ctx, key).Result()

	if err != nil {
		fmt.Printf("Error getting value from Redis for key %s: %v\n", key, err)
		return ""
	}
	fmt.Printf("Successfully retrieved value from Redis for key %s: %s\n", key, val)
	return val
}

// Verify 检验验证码
func (r RedisStore) Verify(id, answer string, clear bool) bool {
	v := RedisStore{}.Get(id, clear)
	return v == answer
}
