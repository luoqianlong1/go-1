package result

import (
	"github.com/gin-gonic/gin"
	"net/http"
)

// 定义一个结构体
type Result struct {
	Code    int         `json:"code"`
	Message string      `json:"message"`
	Data    interface{} `json:"data"`
}

// 这段代码定义了一个 Success 函数，用于返回一个标准化的 JSON 响应，表示操作成功的情况。
func Success(c *gin.Context, data interface{}) {
	if data == nil {
		data = gin.H{} //如果结构体是空的 json数据也是空的
	}
	res := Result{
		Code:    int(ApiCode.SUCCESS),
		Message: ApiCode.GetMessage(ApiCode.SUCCESS),
		Data:    data,
	}
	c.JSON(http.StatusOK, res)
}

// 这段代码定义了一个 Failed 函数，用于返回一个标准化的 JSON 响应，表示操作失败的情况。
func Failed(c *gin.Context, code int, message string) {
	res := Result{
		Code:    code,
		Message: message,
		Data:    gin.H{},
	}
	c.JSON(http.StatusOK, res) //返回一个res序列化的结构体
}
