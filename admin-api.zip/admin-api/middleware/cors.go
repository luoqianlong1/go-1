// 跨域中间件配置
// author
// 声明 middleware 包
package middleware

import (
	"github.com/gin-gonic/gin"
	"net/http"
)

// Cors 跨域处理
// gin.HandlerFunc 是 Gin 框架中的处理函数类型
// Cors 跨域处理
// 什么是跨域请求
func Cors() gin.HandlerFunc {
	return func(c *gin.Context) {
		method := c.Request.Method
		c.Header("Access-Control-Allow-Origin", "*") //要说有域名访问
		c.Header("Access-Control-Allow-Methods", "POST, GET, OPTIONS")
		c.Header("Access-Control-Allow-Headers", "Content-Type,AccessToken,X-CSRF-Token, Authorization, Token")
		if method == "OPTIONS" {
			c.AbortWithStatus(http.StatusNoContent) //这个是什么
			return
		}
		c.Next()
	}
}
