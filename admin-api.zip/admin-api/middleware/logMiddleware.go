// 操作日志中间件

package middleware

import (
	"admin-api/api/dao"
	"admin-api/api/entity"
	"admin-api/common/util"
	"admin-api/pkg/jwt"
	"github.com/gin-gonic/gin"
	"strings"
	"time"
)

// LogMiddleware 操作日志中间件，用于记录所有非GET请求的操作日志
func LogMiddleware() gin.HandlerFunc {
	return func(c *gin.Context) {
		method := strings.ToLower(c.Request.Method) // 获取请求方法并转为小写
		sysAdmin, _ := jwt.GetAdmin(c)              // 从上下文中获取当前管理员信息
		if method != "get" {                        // 仅记录非GET请求
			log := entity.SysOperationLog{
				AdminId:    sysAdmin.ID,                  // 设置管理员ID
				Username:   sysAdmin.Username,            // 设置管理员用户名
				Method:     method,                       // 设置请求方法
				Ip:         c.ClientIP(),                 // 获取并设置客户端IP地址
				Url:        c.Request.URL.Path,           // 获取并设置请求的URL路径
				CreateTime: util.HTime{Time: time.Now()}, // 设置创建时间
			}
			dao.CreateSysOperationLog(log) // 创建操作日志记录
		}
		c.Next() // 继续处理请求
	}
}
