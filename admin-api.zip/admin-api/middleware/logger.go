// middleware/logger.go

// 日志log中间件
// 作者: xiao骆

package middleware

import (
	"admin-api/pkg/log" // 引入日志包
	"bytes"
	"github.com/gin-gonic/gin"
	"github.com/sirupsen/logrus"
	"io/ioutil"
	"time"
)

// Logger 返回一个gin中间件，负责记录每个请求的详细日志
func Logger() gin.HandlerFunc {
	logger := log.Log() // 获取logrus的Logger实例

	return func(c *gin.Context) {
		// 开始时间
		startTime := time.Now()
		bodyBytes, _ := ioutil.ReadAll(c.Request.Body) //ioutil是啥Request.Body)
		c.Request.Body = ioutil.NopCloser(bytes.NewReader(bodyBytes))
		c.Next() //c.Next是什么

		endTime := time.Now()
		latencyTime := endTime.Sub(startTime) / time.Millisecond
		reqMethod := c.Request.Method
		reqUri := c.Request.RequestURI
		proto := c.Request.Proto
		statusCode := c.Writer.Status()
		clientIP := c.ClientIP()
		logger.WithFields(logrus.Fields{
			"status_code":  statusCode,
			"latency_time": latencyTime.String(), // 执行时间
			"client_ip":    clientIP,
			"req_method":   reqMethod,
			"req_uri":      reqUri,
			"proto":        proto,
			"body":         string(bodyBytes), // 请求体内容
			//	"err":          err,               // 错误信息
		}).Info("请求日志")
	}
}
