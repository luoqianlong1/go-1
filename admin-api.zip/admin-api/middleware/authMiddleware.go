// 鉴权中间件

package middleware

import (
	"admin-api/common/constant" // 导入常量定义
	"admin-api/common/result"   // 导入处理结果相关的工具包
	"admin-api/pkg/jwt"
	"github.com/gin-gonic/gin" // 导入Gin框架
	"strings"                  // 导入strings包，用于字符串操作
)

// AuthMiddleware 鉴权  Authentication Middleware.
func AuthMiddleware() func(c *gin.Context) {
	return func(c *gin.Context) {
		authHeader := c.Request.Header.Get("Authorization") // 从请求头中获取Authorization字段
		//这段函数的作用
		// 如果Authorization头为空，则返回无授权错误，并终止请求处理
		if authHeader == "" {
			result.Failed(c, int(result.ApiCode.NOAUTH), //发挥apicode 代码函数量
				result.ApiCode.GetMessage(result.ApiCode.NOAUTH)) //输出返回false
			c.Abort() // 终止请求处理

			//c.Abort() 的作用是终止当前请求的处理流程。具体来说，它会停止执行后续的中间件和处理函数，直接返回当前的响应。
			return
		}

		// 尝试以空格分割Authorization头，预期格式为"Bearer TOKEN"
		parts := strings.SplitN(authHeader, " ", 2)
		// 如果格式不符合预期，则返回格式错误信息，并终止请求处理
		if !(len(parts) == 2 && parts[0] == "Bearer") { //则返回格式错误信息，并终止请求处理
			result.Failed(c, int(result.ApiCode.AUTHFORMATERROR), //什么变量导入
				result.ApiCode.GetMessage(result.ApiCode.AUTHFORMATERROR))
			c.Abort() // 终止请求处理
			return
		}

		// todo 检验token
		mc, err := jwt.ValidateToken(parts[1])
		if err != nil {
			result.Failed(c, int(result.ApiCode.INVALIDTOKEN), result.ApiCode.GetMessage(result.ApiCode.INVALIDTOKEN))
			c.Abort()
			return
		} //失败了 就直接下一个
		// 存用户信息
		c.Set(constant.ContextKeyUserObj, mc) //将token存储在Gin的上下文中，以供后续中间件或处理函数使用

		c.Next() // 继续执行后续的请求处理链
	}
}
