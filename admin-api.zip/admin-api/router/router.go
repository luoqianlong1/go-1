// 访问接口路由配置

package router

import (
	"admin-api/api/controller"
	"admin-api/common/config"
	"admin-api/middleware"
	"github.com/gin-gonic/gin"
	swaggerFiles "github.com/swaggo/files"     //这是什么 为什么要加上
	ginSwagger "github.com/swaggo/gin-swagger" //这是什么 为什么要加上
	"net/http"
)

// InitRouter 初始化路由
func InitRouter() *gin.Engine { //这个又是什么定义

	router := gin.New()

	router.StaticFS(config.Config.ImageSettings.UploadDir, http.Dir(config.Config.ImageSettings.UploadDir))
	// 使用 Gin 的 Recovery 中间件，捕获所有 panic 并恢复，防止程序崩溃
	router.Use(gin.Recovery())
	//这是什么函数起什么作用

	// 使用自定义的跨域中间件，允许跨域请求
	router.Use(middleware.Cors())

	// 使用自定义的日志中间件，记录请求日志
	router.Use(middleware.Logger())

	// 注册路由
	register(router)

	return router
}

// register 注册路由
func register(router *gin.Engine) {
	// 验证码接口
	router.GET("/api/captcha", controller.Captcha)

	// Swagger 文档接口
	router.GET("/swagger/*any", ginSwagger.WrapHandler(swaggerFiles.Handler))

	// 登录接口
	router.POST("/api/login", controller.Login)

	// 需要 JWT 鉴权的接口组
	jwt := router.Group("/api", middleware.AuthMiddleware())
	{
		// 岗位管理相关接口
		jwt.POST("/post/add", controller.CreateSysPost)
		jwt.GET("/post/list", controller.GetSysPostList)
		jwt.GET("/post/info", controller.GetSysPostById)
		jwt.PUT("/post/update", controller.UpdateSysPost)
		jwt.DELETE("/post/delete", controller.DeleteSysPostById)
		jwt.DELETE("/post/batch/delete", controller.BatchDeleteSysPost)
		jwt.PUT("/post/updateStatus", controller.UpdateSysPostStatus)
		jwt.GET("/post/vo/list", controller.QuerySysPostVoList)

		// 部门管理相关接口
		jwt.GET("/dept/list", controller.GetSysDeptList)
		jwt.POST("/dept/add", controller.CreateSysDept)
		jwt.GET("/dept/info", controller.GetSysDeptById)
		jwt.PUT("/dept/update", controller.UpdateSysDept)
		jwt.DELETE("/dept/delete", controller.DeleteSysDeptById)
		jwt.GET("/dept/vo/list", controller.QuerySysDeptVoList)

		// 菜单管理相关接口
		jwt.POST("/menu/add", controller.CreateSysMenu)
		jwt.GET("/menu/vo/list", controller.QuerySysMenuVoList)
		jwt.GET("/menu/info", controller.GetSysMenu)
		jwt.PUT("/menu/update", controller.UpdateSysMenu)
		jwt.DELETE("/menu/delete", controller.DeleteSysRoleMenu)
		jwt.GET("/menu/list", controller.GetSysMenuList)

		// 角色管理相关接口
		jwt.POST("/role/add", controller.CreateSysRole)
		jwt.GET("/role/info", controller.GetSysRoleById)
		jwt.PUT("/role/update", controller.UpdateSysRole)
		jwt.DELETE("/role/delete", controller.DeleteSysRoleById)
		jwt.PUT("/role/updateStatus", controller.UpdateSysRoleStatus)
		jwt.GET("/role/list", controller.GetSysRoleList)
		jwt.GET("/role/vo/list", controller.QuerySysRoleVoList)
		jwt.GET("/role/vo/idList", controller.QueryRoleMenuIdList)
		jwt.PUT("/role/assignPermissions", controller.AssignPermissions)

		// 用户管理相关接口
		jwt.POST("/admin/add", controller.CreateSysAdmin)
		jwt.GET("/admin/info", controller.GetSysAdminInfo)
		jwt.PUT("/admin/update", controller.UpdateSysAdmin)
		jwt.DELETE("/admin/delete", controller.DeleteSysAdminById)
		jwt.PUT("/admin/updateStatus", controller.UpdateSysAdminStatus)
		jwt.PUT("/admin/updatePassword", controller.ResetSysAdminPassword)
		jwt.GET("/admin/list", controller.GetSysAdminList)

		// 文件上传接口
		jwt.POST("/upload", controller.Upload)

		// 个人信息管理相关接口
		jwt.PUT("/admin/updatePersonal", controller.UpdatePersonal)
		jwt.PUT("/admin/updatePersonalPassword", controller.UpdatePersonalPassword)

		// 配置登录日志相关路由
		jwt.GET("/sysLoginInfo/list", controller.GetSysLoginInfoList)
		jwt.DELETE("/sysLoginInfo/batch/delete", controller.BatchDeleteSysLoginInfo)
		jwt.DELETE("/sysLoginInfo/delete", controller.DeleteSysLoginInfoById)
		jwt.DELETE("/sysLoginInfo/clean", controller.CleanSysLoginInfo)

		// 配置操作日志相关路由，并使用日志中间件
		jwt.GET("/sysOperationLog/list", middleware.LogMiddleware(), controller.GetSysOperationLogList)                // 配置获取操作日志列表的路由
		jwt.DELETE("/sysOperationLog/delete", middleware.LogMiddleware(), controller.DeleteSysOperationLogById)        // 配置删除单条操作日志的路由
		jwt.DELETE("/sysOperationLog/batch/delete", middleware.LogMiddleware(), controller.BatchDeleteSysOperationLog) // 配置批量删除操作日志的路由
		jwt.DELETE("/sysOperationLog/clean", middleware.LogMiddleware(), controller.CleanSysOperationLog)              // 配置清空操作日志的路由
	}
}
