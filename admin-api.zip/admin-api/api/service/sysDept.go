package service

import (
	"admin-api/api/dao"        // 导入数据访问对象包
	"admin-api/api/entity"     // 导入实体包
	"admin-api/common/result"  // 导入结果处理包
	"github.com/gin-gonic/gin" // 导入Gin Web框架包
)

// ISysDeptService defines the department service interface with methods for department management
// ISysDeptService 定义部门服务接口，包含部门管理的各种方法
type ISysDeptService interface {
	// CreateSysDept - Create a new department创建部门
	CreateSysDept(c *gin.Context, sysDept entity.SysDept)
	// QuerySysDeptVoList - Query department dropdown list 查询部门下拉列表
	QuerySysDeptVoList(c *gin.Context)
	// GetSysDeptById - Get department by ID根据ID查询部
	GetSysDeptById(c *gin.Context, Id int)
	// UpdateSysDept - Update department 更新部门
	UpdateSysDept(c *gin.Context, dept entity.SysDept)
	// DeleteSysDeptById - Delete department by ID根据ID删除部门
	DeleteSysDeptById(c *gin.Context, dto entity.SysDeptIdDto)
	// GetSysDeptList - Get list of departments查询部门列表
	GetSysDeptList(c *gin.Context, DeptName string, DeptStatus string)
}

// SysDeptServiceImpl 实现 ISysDeptService 接口
type SysDeptServiceImpl struct{}

// GetSysDeptList 查询部门列表并返回结果
func (s SysDeptServiceImpl) GetSysDeptList(c *gin.Context, DeptName string, DeptStatus string) {
	result.Success(c, dao.GetSysDeptList(DeptName, DeptStatus))
}

// DeleteSysDeptById 根据ID删除部门并返回结果
func (s SysDeptServiceImpl) DeleteSysDeptById(c *gin.Context, dto entity.SysDeptIdDto) {
	bool := dao.DeleteSysDeptById(dto)
	if !bool {
		result.Failed(c, int(result.ApiCode.DEPTISDISTRIBUTE), result.ApiCode.GetMessage(result.ApiCode.DEPTISDISTRIBUTE))
		return
	}
	result.Success(c, true)
}

// UpdateSysDept 更新部门并返回结果
func (s SysDeptServiceImpl) UpdateSysDept(c *gin.Context, dept entity.SysDept) {
	sysDept := dao.UpdateSysDept(dept)
	result.Success(c, sysDept)
}

// GetSysDeptById 根据ID查询部门并返回结果
func (s SysDeptServiceImpl) GetSysDeptById(c *gin.Context, Id int) {
	result.Success(c, dao.GetSysDeptById(Id))
}

// QuerySysDeptVoList 查询部门下拉列表并返回结果
func (s SysDeptServiceImpl) QuerySysDeptVoList(c *gin.Context) {
	result.Success(c, dao.QuerySysDeptVoList())
}

// CreateSysDept 创建部门并返回结果
func (s SysDeptServiceImpl) CreateSysDept(c *gin.Context, sysDept entity.SysDept) {
	bool := dao.CreateSysDept(sysDept)
	if !bool {
		result.Failed(c, int(result.ApiCode.DEPTISEXIST), result.ApiCode.GetMessage(result.ApiCode.DEPTISEXIST))
		return
	}
	result.Success(c, true)
}

// sysDeptService 是 SysDeptServiceImpl 的实例
var sysDeptService = SysDeptServiceImpl{}

// SysDeptService 返回 ISysDeptService 接口的实现
func SysDeptService() ISysDeptService {
	return &sysDeptService
}
