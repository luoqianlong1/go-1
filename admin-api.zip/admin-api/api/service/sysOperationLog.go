// 操作日志服务层

package service

import (
	"admin-api/api/dao"
	"admin-api/api/entity"
	"admin-api/common/result"
	"github.com/gin-gonic/gin"
)

// ISysOperationLogService 定义操作日志服务接口
type ISysOperationLogService interface {
	GetSysOperationLogList(c *gin.Context, Username, BeginTime, EndTime string, PageSize, PageNum int) // 分页获取操作日志列表
	DeleteSysOperationLogById(c *gin.Context, dto entity.SysOperationLogIdDto)                         // 根据ID删除操作日志
	BatchDeleteSysOperationLog(c *gin.Context, dto entity.BatchDeleteSysOperationLogDto)               // 批量删除操作日志
	CleanSysOperationLog(c *gin.Context)                                                               // 清空操作日志
}

// SysOperationLogServiceImpl 实现操作日志服务接口
type SysOperationLogServiceImpl struct{}

// CleanSysOperationLog 清空所有操作日志
func (s SysOperationLogServiceImpl) CleanSysOperationLog(c *gin.Context) {
	dao.CleanSysOperationLog() // 调用数据层方法清空操作日志
	result.Success(c, true)    // 返回成功结果
}

// BatchDeleteSysOperationLog 批量删除操作日志
func (s SysOperationLogServiceImpl) BatchDeleteSysOperationLog(c *gin.Context, dto entity.BatchDeleteSysOperationLogDto) {
	dao.BatchDeleteSysOperationLog(dto) // 调用数据层方法批量删除操作日志
	result.Success(c, true)             // 返回成功结果
}

// DeleteSysOperationLogById 根据ID删除操作日志
func (s SysOperationLogServiceImpl) DeleteSysOperationLogById(c *gin.Context, dto entity.SysOperationLogIdDto) {
	dao.DeleteSysOperationLogById(dto) // 调用数据层方法根据ID删除操作日志
	result.Success(c, true)            // 返回成功结果
}

// GetSysOperationLogList 分页获取操作日志列表
func (s SysOperationLogServiceImpl) GetSysOperationLogList(c *gin.Context, Username, BeginTime, EndTime string, PageSize, PageNum int) {
	if PageSize < 1 {
		PageSize = 10 // 默认每页显示10条记录
	}
	if PageNum < 1 {
		PageNum = 1 // 默认第1页
	}
	sysOperationLog, count := dao.GetSysOperationLogList(Username, BeginTime, EndTime, PageSize, PageNum)                        // 调用数据层方法获取操作日志列表
	result.Success(c, map[string]interface{}{"total": count, "pageSize": PageSize, "pageNum": PageNum, "list": sysOperationLog}) // 返回查询结果
}

var sysOperationLogService = SysOperationLogServiceImpl{}

// SysOperationLogService 返回操作日志服务实例
func SysOperationLogService() ISysOperationLogService {
	return &sysOperationLogService
}
