package service

import (
	"admin-api/api/dao"        // 引入dao包
	"admin-api/api/entity"     // 引入entity包
	"admin-api/common/result"  // 引入result包
	"github.com/gin-gonic/gin" // 引入gin框架
)

// ISysLoginInfoService 定义登录日志服务接口
type ISysLoginInfoService interface {
	GetSysLoginInfoList(c *gin.Context, Username, LoginStatus, BeginTime, EndTime string, PageSize, PageNum int) // 分页获取登录日志列表
	BatchDeleteSysLoginInfo(c *gin.Context, dto entity.DelSysLoginInfoDto)                                       // 批量删除登录日志
	DeleteSysLoginInfo(c *gin.Context, dto entity.SysLoginInfoIdDto)                                             // 根据ID删除登录日志
	CleanSysLoginInfo(c *gin.Context)                                                                            // 清空登录日志
}

// SysLoginInfoServiceImpl 实现登录日志服务接口
type SysLoginInfoServiceImpl struct{}

// GetSysLoginInfoList 分页获取登录日志列表
func (s SysLoginInfoServiceImpl) GetSysLoginInfoList(c *gin.Context, Username, LoginStatus, BeginTime, EndTime string, PageSize, PageNum int) {
	if PageSize < 1 { // 如果每页记录数小于1
		PageSize = 10 // 设置每页记录数为10
	}
	if PageNum < 1 { // 如果页码小于1
		PageNum = 1 // 设置页码为1
	}
	sysLoginInfo, count := dao.GetSysLoginInfoList(Username, LoginStatus, BeginTime, EndTime, PageSize, PageNum)              // 调用dao层方法获取登录日志列表
	result.Success(c, map[string]interface{}{"total": count, "pageSize": PageSize, "pageNum": PageNum, "list": sysLoginInfo}) // 返回成功结果
}

// BatchDeleteSysLoginInfo 批量删除登录日志
func (s SysLoginInfoServiceImpl) BatchDeleteSysLoginInfo(c *gin.Context, dto entity.DelSysLoginInfoDto) {
	dao.BatchDeleteSysLoginInfo(dto) // 调用dao层方法批量删除登录日志
	result.Success(c, true)          // 返回成功结果
}

// DeleteSysLoginInfo 根据ID删除登录日志
func (s SysLoginInfoServiceImpl) DeleteSysLoginInfo(c *gin.Context, dto entity.SysLoginInfoIdDto) {
	dao.DeleteSysLoginInfoById(dto) // 调用dao层方法根据ID删除登录日志
	result.Success(c, true)         // 返回成功结果
}

// CleanSysLoginInfo 清空所有登录日志
func (s SysLoginInfoServiceImpl) CleanSysLoginInfo(c *gin.Context) {
	dao.CleanSysLoginInfo() // 调用dao层方法清空登录日志
	result.Success(c, true) // 返回成功结果
}

var sysLoginInfoService = SysLoginInfoServiceImpl{} // 创建SysLoginInfoServiceImpl实例

// SysLoginInfoService 返回登录日志服务实例
func SysLoginInfoService() ISysLoginInfoService {
	return &sysLoginInfoService // 返回登录日志服务实例
}
