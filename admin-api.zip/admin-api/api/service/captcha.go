//package service 服务

package service

import (
	"admin-api/common/util"
	"github.com/mojocn/base64Captcha"
	"image/color"
	// 确保这里使用了正确的包路径
)

// 使用redis作为store
var store = util.RedisStore{} //Redis不是有结构体的·方法captcha := base64Captcha.NewCaptcha(driver, store)为什么能被这个使用‘

// CaptMake 生成验证码
func CaptMake() (id, b64s string) {
	var driver base64Captcha.Driver
	var driverString base64Captcha.DriverString
	// 配置验证码信息
	captchaConfig := base64Captcha.DriverString{
		Height:          60,
		Width:           200,
		NoiseCount:      0,
		ShowLineOptions: 2 | 4,
		Length:          6,
		Source:          "1234567890qwertyuioplkjhgfdsazxcvbnm",
		BgColor: &color.RGBA{
			R: 3,
			G: 102,
			B: 214,
			A: 125,
		},
		Fonts: []string{"wqy-microhei.ttc"}, //这里的fonts字体结构就是wps那种字体设置
	}
	driverString = captchaConfig
	//driver设置成结构体
	driver = driverString.ConvertFonts() //riverString 类型的字体配置转换为实际可用的字体  、
	//  convertFonts 函数的作用 ？
	//`NewCaptcha` 函数用于创建一个新的验证码对象。
	captcha := base64Captcha.NewCaptcha(driver, store)
	lid, lb64s, _ := captcha.Generate()
	return lid, lb64s
}

// CaptVerify  验证captcha是否正确
func CaptVerify(id string, capt string) bool {
	//验证redis这个是不是正确的
	if store.Verify(id, capt, false) {
		return true
	} else {
		return false
	}
}
