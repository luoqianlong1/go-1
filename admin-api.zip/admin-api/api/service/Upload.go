// 图片上传服务层

package service

import (
	"admin-api/common/config"
	"admin-api/common/result"
	"admin-api/common/util"
	"fmt"
	"github.com/gin-gonic/gin"
	"path"
	"strconv"
	"time"
)

type IUploadService interface {
	Upload(c *gin.Context)
}
type UploadServiceImpl struct{}

func (u UploadServiceImpl) Upload(c *gin.Context) {
	file, err := c.FormFile("file") //写入file
	if err != nil {
		result.Failed(c, int(result.ApiCode.FILEUPLOADERROR),
			result.ApiCode.GetMessage(result.ApiCode.FILEUPLOADERROR))
	}
	now := time.Now()              //定义时间
	ext := path.Ext(file.Filename) //获取文件扩展名
	fileName := strconv.Itoa(now.Nanosecond()) + ext
	//将当前时间的纳秒数转换为字符串，并将扩展名附加到其后，形成文件名。 这样可以保证文件名是唯一的。
	filePath := fmt.Sprintf("%s%s%s%s",
		config.Config.ImageSettings.UploadDir,
		fmt.Sprintf("%04d", now.Year()),
		fmt.Sprintf("%02d", now.Month()),
		fmt.Sprintf("%04d", now.Day()))
	util.CreateDir(filePath)
	fullPath := filePath + "/" + fileName
	c.SaveUploadedFile(file, fullPath)
	result.Success(c, fullPath)
}

var uploadService = UploadServiceImpl{}

func UploadService() IUploadService {
	return &uploadService
}
