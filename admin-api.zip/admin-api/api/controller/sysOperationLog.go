// 操作日志控制层

package controller

import (
	"admin-api/api/entity"
	"admin-api/api/service"
	"github.com/gin-gonic/gin"
	"strconv"
)

// GetSysOperationLogList 分页获取操作日志列表
// @Summary 分页获取操作日志列表接口
// @Produce json
// @Description 分页获取操作日志列表接口
// @Param PageSize query int false "每页数"
// @Param PageNum query int false "分页数"
// @Param Username query string false "用户名"
// @Param BeginTime query string false "开始时间"
// @Param EndTime query string false "结束时间"
// @Success 200 {object} result.Result
// @router /api/sysOperationLog/list [get]
// @Security ApiKeyAuth
func GetSysOperationLogList(c *gin.Context) {
	Username := c.Query("username")                                                                             // 获取查询参数：用户名
	BeginTime := c.Query("beginTime")                                                                           // 获取查询参数：开始时间
	EndTime := c.Query("endTime")                                                                               // 获取查询参数：结束时间
	PageSize, _ := strconv.Atoi(c.Query("pageSize"))                                                            // 获取查询参数：每页记录数
	PageNum, _ := strconv.Atoi(c.Query("pageNum"))                                                              // 获取查询参数：页码
	service.SysOperationLogService().GetSysOperationLogList(c, Username, BeginTime, EndTime, PageSize, PageNum) // 调用服务层方法获取操作日志列表
}

// DeleteSysOperationLogById 根据ID删除操作日志
// @Summary 根据ID删除操作日志
// @Produce json
// @Description 根据ID删除操作日志
// @Param data body entity.SysOperationLogIdDto true "data"
// @Success 200 {object} result.Result
// @router /api/sysOperationLog/delete [delete]
// @Security ApiKeyAuth
func DeleteSysOperationLogById(c *gin.Context) {
	var dto entity.SysOperationLogIdDto
	_ = c.BindJSON(&dto)                                               // 绑定请求体到DTO
	service.SysOperationLogService().DeleteSysOperationLogById(c, dto) // 调用服务层方法根据ID删除操作日志
}

// BatchDeleteSysOperationLog 批量删除操作日志
// @Summary 批量删除操作日志接口
// @Produce json
// @Description 批量删除操作日志接口
// @Param data body entity.BatchDeleteSysOperationLogDto true "data"
// @Success 200 {object} result.Result
// @router /api/sysOperationLog/batch/delete [delete]
// @Security ApiKeyAuth
func BatchDeleteSysOperationLog(c *gin.Context) {
	var dto entity.BatchDeleteSysOperationLogDto
	_ = c.BindJSON(&dto)                                                // 绑定请求体到DTO
	service.SysOperationLogService().BatchDeleteSysOperationLog(c, dto) // 调用服务层方法批量删除操作日志
}

// CleanSysOperationLog 清空操作日志
// @Summary 清空操作日志接口
// @Produce json
// @Description 清空操作日志接口
// @Success 200 {object} result.Result
// @router /api/sysOperationLog/clean [delete]
// @Security ApiKeyAuth
func CleanSysOperationLog(c *gin.Context) {
	service.SysOperationLogService().CleanSysOperationLog(c) // 调用服务层方法清空操作日志
}
