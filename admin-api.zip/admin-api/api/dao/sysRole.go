package dao

import (
	"admin-api/api/entity"
	"admin-api/common/util"
	. "admin-api/pkg/db" // 直接导入 db 包中的所有内容，可以直接使用 Db 对象
	"time"
)

// GetSysRoleByName 根据角色名称查询角色信息
// 通过角色名称查询数据库中的角色记录，并将结果存储在 sysRole 变量中返回
func GetSysRoleByName(roleName string) (sysRole entity.SysRole) {
	Db.Where("role_name = ?", roleName).First(&sysRole)
	return sysRole
}

// GetSysRoleByKey 根据角色Key查询角色信息
// 通过角色Key查询数据库中的角色记录，并将结果存储在 sysRole 变量中返回
func GetSysRoleByKey(roleKey string) (sysRole entity.SysRole) {
	Db.Where("role_key = ?", roleKey).First(&sysRole)
	return sysRole
}

// CreateSysRole 新增角色
// 根据角色名称和Key检查是否已存在相同记录，如果不存在，则创建新角色
func CreateSysRole(dto entity.AddSysRoleDto) bool {
	sysRoleByName := GetSysRoleByName(dto.RoleName)
	if sysRoleByName.ID > 0 {
		return false // 如果角色名称已存在，返回false
	}
	sysRoleByKey := GetSysRoleByKey(dto.RoleKey)
	if sysRoleByKey.ID > 0 {
		return false // 如果角色Key已存在，返回false
	}
	addSysRole := entity.SysRole{
		RoleName:    dto.RoleName,
		RoleKey:     dto.RoleKey,
		Description: dto.Description,
		Status:      dto.Status,
		CreateTime:  util.HTime{Time: time.Now()},
	}
	tx := Db.Create(&addSysRole) // 创建新角色记录
	if tx.RowsAffected > 0 {
		return true
	}
	return false
}

// GetSysRoleById 根据ID获取角色详情
// 通过角色ID查询数据库中的角色记录，并将结果存储在 sysRole 变量中返回
func GetSysRoleById(Id int) (sysRole entity.SysRole) {
	Db.First(&sysRole, Id)
	return sysRole
}

// UpdateSysRole 修改角色
// 通过角色ID查询角色记录，并根据传入的 DTO 更新角色的相关字段
func UpdateSysRole(dto entity.UpdateSysRoleDto) (sysRole entity.SysRole) {
	Db.First(&sysRole, dto.Id)
	//查询主键符合要求的
	sysRole.RoleName = dto.RoleName
	sysRole.RoleKey = dto.RoleKey
	sysRole.Status = dto.Status
	//赋值
	if dto.Description != "" {
		sysRole.Description = dto.Description
	}
	Db.Save(&sysRole) // 保存更新后的角色记录
	return sysRole
}

// DeleteSysRoleById 根据ID删除角色
// 删除角色记录，并删除与该角色关联的角色菜单记录
func DeleteSysRoleById(dto entity.SysRoleIdDto) {
	Db.Table("sys_role").Delete(&entity.SysRole{}, dto.Id)
	Db.Table("sys_role_menu").Where("role_id = ?", dto.Id).Delete(&entity.SysRoleMenu{})
}

// UpdateSysRoleStatus 角色状态启用/停用
// 根据角色ID查询角色记录，并更新其状态字段
func UpdateSysRoleStatus(dto entity.UpdateSysRoleStatusDto) bool {
	var sysRole entity.SysRole
	Db.First(&sysRole, dto.Id)
	sysRole.Status = dto.Status
	tx := Db.Save(&sysRole)
	if tx.RowsAffected > 0 {
		return true
	}
	return false
}

// GetSysRoleList 分页查询角色列表
// 根据分页参数和查询条件（角色名称、状态、时间范围）查询角色列表
func GetSysRoleList(PageNum int, PageSize int, RoleName string, status string, BeginTime string, EndTime string) (sysRole []*entity.SysRole, count int64) {
	curDb := Db.Table("sys_role")
	//定位·到sys_role中
	if RoleName != "" {
		curDb = curDb.Where("role_name = ?", RoleName)
	} //查找
	if BeginTime != "" && EndTime != "" {
		curDb = curDb.Where("create_time BETWEEN ? AND ?", BeginTime, EndTime)
	} //查找
	if status != "" {
		curDb = curDb.Where("status = ?", status)
	} //
	curDb.Count(&count) //统计人数
	curDb.Limit(PageSize).Offset((PageNum - 1) * PageSize).Order("create_time DESC").Find(&sysRole)
	//这个是真的不知道到=
	return sysRole, count
}

// QuerySysRoleVoList 角色下拉列表
// 查询所有角色的ID和名称，以便用于下拉列表或选择框
func QuerySysRoleVoList() (sysRoleVo []entity.SysRoleVo) {
	Db.Table("sys_role").Select("id, role_name").Scan(&sysRoleVo)
	return sysRoleVo
}

// QueryRoleMenuIdList 根据角色ID查询菜单数据
// 根据角色ID查询与该角色关联的菜单ID列表
func QueryRoleMenuIdList(Id int) (idVo []entity.IdVo) {
	const menuType int = 3
	Db.Table("sys_menu sm").
		Select("sm.id").                                             //展示smid这个列
		Joins("LEFT JOIN sys_role_menu srm ON srm.menu_id = sm.id"). //左连接
		Joins("LEFT JOIN sys_role sr ON sr.id = srm.role_id ").      //左连接
		Where("sm.menu_type = ?", menuType).
		Where("sr.id = ?", Id).
		Scan(&idVo)
	return idVo
}

// AssignPermissions 分配权限
// 首先删除已有的角色菜单关联，然后根据传入的菜单ID列表重新分配角色权限
func AssignPermissions(menu entity.RoleMenu) (err error) {
	err = Db.Table("sys_role_menu").Where("role_id =?", menu.Id).Delete(&entity.SysRoleMenu{}).Error
	if err != nil {
		return err
	}
	for _, value := range menu.MenuIds {
		var entity entity.SysRoleMenu
		entity.RoleId = menu.Id
		entity.MenuId = value
		Db.Create(&entity)
	}
	return err
}
