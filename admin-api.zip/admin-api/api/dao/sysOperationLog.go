// 操作日志数据层
// author
package dao

import (
	"admin-api/api/entity"
	. "admin-api/pkg/db"
)

// CreateSysOperationLog 创建新的操作日志记录
func CreateSysOperationLog(log entity.SysOperationLog) {
	Db.Create(&log) // 向数据库插入新的操作日志记录
}

// GetSysOperationLogList 分页获取操作日志列表
func GetSysOperationLogList(Username, BeginTime, EndTime string, PageSize, PageNum int) (sysOperationLog []entity.SysOperationLog, count int64) {
	curDb := Db.Table("sys_operation_log") // 设置查询表为sys_operation_log
	if Username != "" {                    // 如果用户名不为空，添加查询条件
		curDb = curDb.Where("username = ?", Username)
	}
	if BeginTime != "" && EndTime != "" { // 如果开始时间和结束时间不为空，添加查询条件
		curDb = curDb.Where("`create_time` BETWEEN ? AND ?", BeginTime, EndTime)
	}
	curDb.Count(&count)                                                                                     // 获取总记录数
	curDb.Limit(PageSize).Offset((PageNum - 1) * PageSize).Order("create_time desc").Find(&sysOperationLog) // 分页查询操作日志记录
	return sysOperationLog, count
}

// DeleteSysOperationLogById 根据ID删除操作日志
func DeleteSysOperationLogById(dto entity.SysOperationLogIdDto) {
	Db.Delete(&entity.SysOperationLog{}, dto.Id) // 根据ID删除操作日志
}

// BatchDeleteSysOperationLog 批量删除操作日志
func BatchDeleteSysOperationLog(dto entity.BatchDeleteSysOperationLogDto) {
	Db.Where("id in (?)", dto.Ids).Delete(&entity.SysOperationLog{}) // 根据ID列表批量删除操作日志
}

// CleanSysOperationLog 清空所有操作日志
func CleanSysOperationLog() {
	Db.Exec("truncate table sys_operation_log") // 清空操作日志表
}
