// author
package dao

import (
	"admin-api/api/entity"
	"admin-api/common/util"
	. "admin-api/pkg/db"
	"time"
)

// GetSysPostByCode 根据编码查询
func GetSysPostByCode(postCode string) (sysPost entity.SysPost) {
	//这个db就是一个对象
	Db.Where("post_code = ?", postCode).First(&sysPost)
	return sysPost //把查询的结果给 sysPost
}

// GetSysPostByName 根据名称查询
func GetSysPostByName(postName string) (sysPost entity.SysPost) {
	Db.Where("post_name = ?", postName).First(&sysPost)
	return sysPost
}

// CreateSysPost 新增岗位
func CreateSysPost(sysPost entity.SysPost) bool {
	//判断是否存在存在就是false 是不是存在存在直接就是false
	sysPostByCode := GetSysPostByCode(sysPost.PostCode)
	if sysPostByCode.ID > 0 {
		return false
	}
	sysPostByName := GetSysPostByName(sysPost.PostName)
	if sysPostByName.ID > 0 {
		return false
	}
	addSysPost := entity.SysPost{
		PostCode:   sysPost.PostCode,
		PostName:   sysPost.PostName,
		PostStatus: sysPost.PostStatus,
		CreateTime: util.HTime{Time: time.Now()},
		Remark:     sysPost.Remark,
	}
	//存入数据库中
	tx := Db.Save(&addSysPost)
	return tx.RowsAffected > 0
}

// GetSysPostById 根据id查询岗位
func GetSysPostById(Id int) (sysPost entity.SysPost) {
	Db.First(&sysPost, Id)
	return sysPost
}

// UpdateSysPost 修改岗位
func UpdateSysPost(post entity.SysPost) (sysPost entity.SysPost) {
	Db.First(&sysPost, post.ID)
	sysPost.PostName = post.PostName
	sysPost.PostCode = post.PostCode
	sysPost.PostStatus = post.PostStatus
	if post.Remark != "" {
		sysPost.Remark = post.Remark
	}
	Db.Save(&sysPost)
	return sysPost
}

// DeleteSysPostById 根据id删除岗位
func DeleteSysPostById(dto entity.SysPostIdDto) {
	Db.Delete(&entity.SysPost{}, dto.Id)
} //id
//已经有结构体了为什么要有过定义多个结构体，可以更清晰地表示不同的用途和上下文，确保代码的可读性和可维护性。这种方式不仅提高了代码的清晰度，还减少了不必要的数据传输

// BatchDeleteSysPost 批量删除岗位
func BatchDeletSeysPost(dto entity.DelSysPostDto) {
	Db.Where("id in (?)", dto.Ids).Delete(&entity.SysPost{})
}

// UpdateSysPostStatus 修改状态
func UpdateSysPostStatus(dto entity.UpdateSysPostStatusDto) {
	var sysPost entity.SysPost
	//定义sysPost
	Db.First(&sysPost, dto.Id)
	//修改放入sysPost中
	sysPost.PostStatus = dto.PostStatus
	Db.Save(&sysPost)
}

// GetSysPostList 分页查询岗位列表
// 参数:
//   - PageNum: 当前页码
//   - PageSize: 每页记录数
//   - PostName: 岗位名称（可选）
//   - PostStatus: 岗位状态（可选）
//   - BeginTime: 创建时间起始（可选）
//   - EndTime: 创建时间结束（可选）
//
// 返回值:
//   - sysPost: 查询到的岗位列表
//   - count: 满足条件的岗位总数
func GetSysPostList(PageNum, PageSize int, PostName, PostStatus, BeginTime, EndTime string) (sysPost []entity.SysPost, count int64) {
	// 初始化查询表为 "sys_post"
	curDb := Db.Table("sys_post")

	// 如果提供了岗位名称，则添加相应的查询条件
	if PostName != "" {
		curDb = curDb.Where("post_name = ?", PostName)
	}

	// 如果提供了创建时间范围，则添加相应的查询条件
	if BeginTime != "" && EndTime != "" {
		curDb = curDb.Where("create_time BETWEEN ? AND ?", BeginTime, EndTime)
	}

	// 如果提供了岗位状态，则添加相应的查询条件
	if PostStatus != "" {
		curDb = curDb.Where("post_status = ?", PostStatus)
	}

	// 统计满足条件的岗位总数
	curDb.Count(&count)

	// 查询满足条件的岗位记录，并按创建时间降序排序，分页返回
	curDb.Limit(PageSize).Offset((PageNum - 1) * PageSize).Order("create_time desc").Find(&sysPost)

	return sysPost, count
}

// QuerySysPostVoList 岗位下拉列表
func QuerySysPostVoList() (sysPostVo []entity.SysPostVo) {
	Db.Table("sys_post").Select("id, post_name").Scan(&sysPostVo)
	return sysPostVo
}
