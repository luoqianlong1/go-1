// 登录日志数据层
package dao

import (
	"admin-api/api/entity" // 引入entity包
	"admin-api/common/util"
	. "admin-api/pkg/db" // 引入db包
	"time"
)

// CreateSysLoginInfo 新增登录日志记录
func CreateSysLoginInfo(username, ipAddress, loginLocation, browser, os, message string, loginStatus int) {
	//先建立一个结构体
	sysLoginInfo := entity.SysLoginInfo{
		Username:      username,                     // 设置用户名
		IpAddress:     ipAddress,                    // 设置登录IP地址
		LoginLocation: loginLocation,                // 设置登录地点
		Browser:       browser,                      // 设置浏览器类型
		Os:            os,                           // 设置操作系统
		Message:       message,                      // 设置提示消息
		LoginStatus:   loginStatus,                  // 设置登录状态
		LoginTime:     util.HTime{Time: time.Now()}, // 设置登录时间
	}
	Db.Save(&sysLoginInfo) // 保存登录日志记录到数据库
}

// GetSysLoginInfoList 分页获取登录日志列表 get system login Info list
func GetSysLoginInfoList(Username, LoginStatus, BeginTime, EndTime string, PageSize, PageNum int) (sysLoginInfo []entity.SysLoginInfo, count int64) {
	curDb := Db.Table("sys_login_info") // 设置查询表为sys_login_info
	if Username != "" {                 // 如果用户名不为空
		curDb = curDb.Where("username = ?", Username) // 添加用户名查询条件
	}
	if BeginTime != "" && EndTime != "" { // 如果开始时间和结束时间不为空
		curDb = curDb.Where("`login_time` BETWEEN ? AND ?", BeginTime, EndTime) // 添加时间范围查询条件
	}
	if LoginStatus != "" { // 如果登录状态不为空
		curDb = curDb.Where("login_status = ?", LoginStatus) // 添加登录状态查询条件
	}
	curDb.Count(&count)                                                                                 // 获取总记录数
	curDb.Limit(PageSize).Offset((PageNum - 1) * PageSize).Order("login_time desc").Find(&sysLoginInfo) // 分页查询登录日志记录
	return sysLoginInfo, count                                                                          // 返回查询结果和记录总数
}

// BatchDeleteSysLoginInfo 批量删除登录日志
func BatchDeleteSysLoginInfo(dto entity.DelSysLoginInfoDto) {
	Db.Where("id in (?)", dto.Ids).Delete(&entity.SysLoginInfo{}) // 根据ID列表批量删除登录日志
}

// DeleteSysLoginInfoById 根据ID删除登录日志
func DeleteSysLoginInfoById(dto entity.SysLoginInfoIdDto) {
	Db.Delete(&entity.SysLoginInfo{}, dto.Id) // 根据ID删除登录日志
}

// CleanSysLoginInfo 清空所有登录日志
func CleanSysLoginInfo() {
	Db.Exec("truncate table sys_login_info") // 清空登录日志表
}
