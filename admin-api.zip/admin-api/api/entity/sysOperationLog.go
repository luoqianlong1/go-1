// 操作日志相关结构体
// author
package entity

import "admin-api/common/util"

// SysOperationLog 操作日志结构体
type SysOperationLog struct {
	ID         uint       `gorm:"column:id;comment:'主键';primaryKey;NOT NULL" json:"id"`                 // 主键ID
	AdminId    uint       `gorm:"column:admin_id;comment:'管理员id';NOT NULL" json:"adminId"`              // 管理员ID
	Username   string     `gorm:"column:username;varchar(64);comment:'管理员账号';NOT NULL" json:"username"` // 管理员账号
	Method     string     `gorm:"column:method;varchar(64);comment:'请求方式';NOT NULL" json:"method"`      // 请求方式
	Ip         string     `gorm:"column:ip;varchar(64);comment:'IP'" json:"ip"`                         // IP地址
	Url        string     `gorm:"column:url;varchar(500);comment:'URL'" json:"url"`                     // 请求URL
	CreateTime util.HTime `gorm:"column:create_time;comment:'创建时间';NOT NULL" json:"createTime"`         // 创建时间
}

// TableName 返回操作日志表名
func (SysOperationLog) TableName() string {
	return "sys_operation_log"
}

// SysOperationLogIdDto 用于传递操作日志ID的DTO
type SysOperationLogIdDto struct {
	Id uint `json:"id"` // 操作日志ID
}

// BatchDeleteSysOperationLogDto 批量删除操作日志ID列表的DTO
type BatchDeleteSysOperationLogDto struct {
	Ids []uint `json:"ids"` // 操作日志ID列表
}
