// entity/sys_admin_role.go
package entity

// SysAdminRole 结构体
type SysAdminRole struct {
	RoleId  uint `gorm:"column:role_id;comment:'角色id';NOT NULL" json:"roleId"`   // 角色id
	AdminId uint `gorm:"column:admin_id;comment:'用户id';NOT NULL" json:"adminId"` // 用户id
}

// TableName 返回表名
func (SysAdminRole) TableName() string {
	return "sys_admin_role"
}
