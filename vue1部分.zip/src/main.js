import Vue from 'vue';
import App from './App.vue';
import router from './router/router';
import ElementUI from 'element-ui';
import 'element-ui/lib/theme-chalk/index.css';
import request from '@/utils/request';
import storage from '@/utils/storage';
import store from "@/store";
import './assets/css/global.css';
import api from './api'; // 确保这里导入的是包含 login 方法的 api 模块
import handleTree from '@/utils/common';

Vue.prototype.$handleTree = handleTree;
Vue.prototype.$storage = storage;
Vue.prototype.$request = request;
Vue.prototype.$store = store;
Vue.prototype.$api = api; // 挂载 api 模块到 Vue 原型
Vue.use(ElementUI);
Vue.config.productionTip = false;

new Vue({
  router,
  render: h => h(App),
}).$mount('#app');
