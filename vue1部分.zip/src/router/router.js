/**
 * 路由管理
 * @author xiaoluo
 */

import Vue from "vue";
import Router from "vue-router";
import Login from "@/views/Login"; // 登录页面组件
import Home from "@/views/Home"; // 主页面组件
import storage from "@/utils/storage"; // 本地存储工具
import Admin from "@/views/base/Admin"; // 用户管理页面组件
import Role from "@/views/base/Role"; // 角色管理页面组件
import Welcome from "@/views/Welcome"; // 欢迎页面组件
import Menu from "@/views/base/Menu"; // 菜单管理页面组件
import Dept from "@/views/base/Dept"; // 部门管理页面组件
import Post from "@/views/base/Post"; // 岗位管理页面组件
import Personal from "@/views/Personal"; // 个人信息页面组件
import Operator from "@/views/monitor/Operator"; // 操作日志页面组件
import LoginLog from "@/views/monitor/LoginLog"; // 登录日志页面组件

Vue.use(Router); // 在Vue中使用路由插件  ???

// 各个路由集合
const router = new Router({  //????
    mode: "history", // 使用history模式，避免URL中带有#号
  routes: [
    { path: "/", redirect: "/login" }, // 根路径重定向到登录页面
    { path: "/login", component: Login }, // 登录页面路由
    {
      path: "/home",
      component: Home, // 主页面路由
      redirect: "/welcome", // 默认显示欢迎页面
      children: [//????结构架构是什么
        { path: "/welcome", component: Welcome, meta: { tTitle: "首页" } }, // 欢迎页面路由
        {
          path: "/personal",
          component: Personal,
          meta: { sTitle: "个人中心", tTitle: "个人信息" }, // 个人信息页面路由
        },
        {
          path: "/base/Admin",
          component: Admin,
          meta: { sTitle: "基础管理", tTitle: "用户信息" }, // 用户管理页面路由
        },
        {
          path: "/base/Role",
          component: Role,
          meta: { sTitle: "基础管理", tTitle: "角色信息" }, // 角色管理页面路由
        },
        {
          path: "/base/Menu",
          component: Menu,
          meta: { sTitle: "基础管理", tTitle: "菜单信息" }, // 菜单管理页面路由
        },
        {
          path: "/base/Dept",
          component: Dept,
          meta: { sTitle: "基础管理", tTitle: "部门信息" }, // 部门管理页面路由
        },
        {
          path: "/base/Post",
          component: Post,
          meta: { sTitle: "基础管理", tTitle: "岗位信息" }, // 岗位管理页面路由
        },
        {
          path: "/monitor/Operator",
          component: Operator,
          meta: { sTitle: "监控管理", tTitle: "操作日志" }, // 操作日志页面路由
        },
        {
          path: "/monitor/LoginLog",
          component: LoginLog,
          meta: { sTitle: "监控管理", tTitle: "登录日志" }, // 登录日志页面路由
        },
      ],
    },
  ],
});

// 挂载路由导航守卫
router.beforeEach((to, from, next) => {
  if (to.path === "/login") return next(); // 如果目标路径是登录页面，直接放行
  const tokenStr = storage.getItem("token"); // 从本地存储获取token
  if (!tokenStr) return next("/login"); // 如果没有token，跳转到登录页面
  next(); // 否则放行
});

export default router; // 导出路由实例
