/**
 * 业务数据的提交
 *
 * @author xiaoRui
 */
import storage from "@/utils/storage"
export default {
    saveSysAdmin(state, sysAdmin) {
      state.sysAdmin = sysAdmin;
    },
    saveToken(state, token) {
      state.token = token;
    },
    saveLeftMenuList(state, leftMenuList) {
      state.leftMenuList = leftMenuList;
    },
    savePermissionList(state, permissionList) {
      state.permissionList = permissionList;
    },  
    saveActivePath(state, activePath) {
      state.activePath = activePath
      storage.setItem('activePath', activePath)
    }
  }
  