
<template>
  <div class="tags">
    <el-tag class="tag" size="medium" v-for="item, index in tags" :key="item.path" :effect="item.title == $route.meta.tTitle ? 'dark' : 'plain'" @click="goTo(item.path)" @close="close(index)" :disable-transitions="true" :closable="index > 0">

      <i class="circular" v-show="item.title == $route.meta.tTitle"></i>
      {{ item.title }}
    </el-tag>
  </div>
</template>

<script>
export default {
  data() {
    return {
      tags: [{
        title: "首页",
        path: "/welcome"
      }]
    }
  },
  watch: {
    $route: {
      immediate: true,
      handler(val) {
        const boolean = this.tags.find(item => {
          return val.path == item.path
        })
        if (!boolean) {
          this.tags.push({
            title: val.meta.tTitle,
            path: val.path
          })
        }
      }
    }
  },
  methods: {
    goTo(path) {
      this.$router.push(path)
    },
    close(i) {
      // 跳转到最后一项
      if (this.tags[i].path === this.$route.meta.path && i !== this.tags.length - 1) {
        this.$router.push(this.tags[this.tags.length - 1].path)
      } else if (i === this.tags.length - 1) {
        this.$router.push(this.tags[this.tags.length - 2].path)
      }
      // 关闭当前项，本质上就是删除tags的对应项
      this.tags.splice(i, 1)
    }
  }
}
</script>

<style lang="less" scoped>
.tags {
  padding-left: 20px;
  padding-top: 2px;
  padding-bottom: 2px;

  .tag {
    cursor: pointer;
    margin-right: 3px;

    .circular {
      width: 8px;
      height: 8px;
      margin-right: 4px;
      background-color: #fff;
      border-radius: 50%;
      display: inline-block;
    }
  }
}
</style>