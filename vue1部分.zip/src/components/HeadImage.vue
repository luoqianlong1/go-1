<template>
  <div class="user-info">
    <span class="user-username">{{ sysAdmin.username }}</span>
    <el-dropdown>
      <img v-if="!sysAdmin.icon" src="./../assets/image/logo.jpg" class="user-avatar" />
      <img v-else :src="sysAdmin.icon" class="user-avatar" />
      <el-dropdown-menu>
        <el-dropdown-item>
          <span @click="openPersonal">个人信息</span>
        </el-dropdown-item>
        <el-dropdown-item>
          <span @click="logout" >退出登录</span>
        </el-dropdown-item>
      </el-dropdown-menu>
    </el-dropdown>
  </div>
</template>

<script>
import storage from '@/utils/storage'
export default {
  data() {
    return {
      sysAdmin: storage.getItem("sysAdmin")
    }
  },
  methods: {


    //退出登录
    async logout() {
      const confirmResult = await this.$confirm('确定要退出登录吗, 是否继续?', '提示',
        {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).catch(err => err)
      if (confirmResult !== 'confirm') {
        return this.$message.info('已取消删除')
      }
      this.$storage.clearAll()
      this.$router.push("/login")
      this.$message.success('退出成功');
    },
    openPersonal() {
      this.$router.push("/personal")
    }
  }
}
</script>

<style lang="less" scoped>
.user-info {
  display: flex;
  align-items: center;
  position: absolute;
  right: 20px;
  top: 10px;

  .user-username {
    font-size: medium;
    margin-right: 10px;
  }

  .user-avatar {
    cursor: pointer;
    width: 40px;
    height: 40px;
    border-radius: 50%;
  }
}
</style>