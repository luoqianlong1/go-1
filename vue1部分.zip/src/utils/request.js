/**
 * axios封装
 *
 * @author xiaoluo
 */
import { Message } from "element-ui";
import axios from "axios";
import router from "@/router/router";
import storage from "./storage";
// 创建axios对象，添加全局配置
const service = axios.create({
  baseURL: process.env.VUE_APP_BASE_API,
  timeout: 8000,
});
// 请求拦截
service.interceptors.request.use((req) => {
  const headers = req.headers;
  const token = storage.getItem("token") || {};
  if (!headers.Authorization) {
    headers.Authorization = "Bearer " + token;
  }
  return req;
});
// 响应拦截(除了403和406token认证外，其他的返回，基于严谨在具体的接口判断状态码)
service.interceptors.response.use((res) => {
  const { code, message } = res.data;
  if (code === 403) {
    Message.error(message);
    setTimeout(() => {
      // 清除存储信息
      storage.clearAll();
      router.push("/login");
    }, 1500);
  } else if (code === 406) {
    Message.error(message);
    setTimeout(() => {
      // 清除存储信息
      storage.clearAll();
      router.push("/login");
    }, 1500);
  } else {
    return res;
  }
});
// 请求核心函数
function request(options) {
  options.method = options.method || "get";
  if (options.method.toLowerCase() === "get") {
    options.params = options.data;
  }
  service.defaults.baseURL = process.env.VUE_APP_BASE_API;
  return service(options);
}
export default request;
