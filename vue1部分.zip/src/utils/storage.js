/**
 * Storage封装
 *
 * @author xiaoRui
 */
export default {
  // 获取存储的数据
  getStorage() {
    // 从 localStorage 中获取存储的数据，并将 JSON 字符串解析为对象。
    // 如果不存在对应的存储项，则返回一个空对象 "{}"。
    return JSON.parse(window.localStorage.getItem(process.env.VUE_APP_NAME_SPACE) || "{}");
  },

  // 设置存储的数据
  setItem(key, val) {
    // 获取当前存储的数据对象
    let storage = this.getStorage();
    // 在对象中设置指定 key 的值
    storage[key] = val;
    // 将更新后的对象转换为 JSON 字符串，并存储回 localStorage
    window.localStorage.setItem(process.env.VUE_APP_NAME_SPACE, JSON.stringify(storage));
  },

  // 获取指定 key 的数据
  getItem(key) {
    // 从当前存储的数据对象中获取指定 key 的值
    return this.getStorage()[key];
  },

  // 清除指定 key 的数据
  clearItem(key) {
    // 获取当前存储的数据对象
    let storage = this.getStorage();
    // 删除对象中指定 key 的值
    delete storage[key];
    // 将更新后的对象转换为 JSON 字符串，并存储回 localStorage
    window.localStorage.setItem(process.env.VUE_APP_NAME_SPACE, JSON.stringify(storage));
  },

  // 清除所有数据
  clearAll() {
    // 清空 localStorage 中的所有数据
    window.localStorage.clear();
  }
}
