<!-- eslint-disable vue/multi-word-component-names -->
// eslint-disable-next-line vue/multi-word-component-names

<template>
    <h1>欢迎</h1>
</template>
<script>
</script>
<style>
</style>
  