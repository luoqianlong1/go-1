<!-- eslint-disable vue/multi-word-component-names -->
<template>
    <el-row :gutter="20">
        <el-col :xs="24" :sm="24" :md="8" :lg="6" :xl="5" style="margin-bottom: 10px">
            <el-card class="box-card">
                <div slot="header" class="clearfix">
                    <span>个人信息</span>
                </div>
                <div>
                    <div style="text-align: center">
                        <el-avatar :src="adminDetail.icon"></el-avatar>
                    </div>
                    <el-form label-width="100px" size="mini">
                        <el-row>
                            <el-col :span="24">
                                <el-form-item label="用户账号：">{{ adminDetail.username }}</el-form-item>
                            </el-col>
                            <el-col :span="24">
                                <el-form-item label="用户昵称：">{{ adminDetail.nickname }}</el-form-item>
                            </el-col>
                            <el-col :span="24">
                                <el-form-item label="用户邮箱：">{{ adminDetail.email }}</el-form-item>
                            </el-col>
                            <el-col :span="24">
                                <el-form-item label="用户电话：">{{ adminDetail.phone }}</el-form-item>
                            </el-col>
                            <el-col :span="24">
                                <el-form-item label="用户备注：">{{ adminDetail.note }}</el-form-item>
                            </el-col>
                            <el-col :span="24">
                                <el-form-item label="创建时间：">{{ adminDetail.createTime }}</el-form-item>
                            </el-col>
                        </el-row>
                    </el-form>
                </div>
            </el-card>
        </el-col>
        <el-col :xs="24" :sm="24" :md="16" :lg="18" :xl="19">
            <el-card class="box-card">
                <div slot="header" class="clearfix">
                    <span>基本资料</span>
                </div>




                <el-tabs v-model="activeName">
                    <!-- 这是上面的插槽   用来切换el-tab-pane -->
                    <el-tab-pane label="基本资料" name="first">
                        <el-form :model="adminDetail" :rules="editFormRules" ref="editFormRefForm" label-width="80px">
                            <el-form-item label="用户头像" prop="icon">
                                <el-upload :headers=headers class="avatar-uploader" :action="uploadIconUrl"
                                    :show-file-list="true" :on-success="handleAvatarSuccess">

<!--                 
1. **`el-upload`组件**：
    - `:headers="headers"`：绑定请求头部信息，通常用于携带身份验证token或其他必要信息。
    - `:action="uploadIconUrl"`：指定上传图片的接口地址，`uploadIconUrl`应该是一个API的URL，用于处理头像上传。
    - `:show-file-list="false"`：隐藏上传文件的列表，只显示上传后的图片。
    - `:on-success="handleAvatarSuccess"`：上传成功后触发的回调函数，这个函数通常用于更新头像URL或执行其他逻辑。

2. **`img`标签**：
    - `v-if="icon"`：如果`icon`有值，表示用户已经选择并上传了新的头像，此时会显示这个新的头像。
    - `:src="icon"`：绑定到当前头像的URL，`icon`应该是存储头像URL的变量。
    - `v-else="!icon"`：如果`icon`没有值，使用默认的头像图片。
    - `:src="adminDetail.icon"`：绑定到用户的默认头像，`adminDetail.icon`应该是用户资料中存储的默认头像URL。
    - `class="avatar"`：应用CSS样式类`avatar`，用于控制头像图片的样式。
    - `title="点击更换头像"`：鼠标悬停在图片上时显示的提示文字，提示用户可以点击图片更换头像。

**功能概述**：
- 用户可以点击头像图片触发`el-upload`组件，从而选择并上传新的头像。
- 上传成功后，组件会自动更新显示的新头像。 -->

                                    <img v-if="icon" :src="icon" class="avatar" title="点击更换头像">
                                    <img v-else="!icon" :src="adminDetail.icon" class="avatar" title="点击更换头像">
                                </el-upload>
                            </el-form-item>
                            <el-form-item label="用户账号" prop="username">
                                <el-input v-model="adminDetail.username" />
                            </el-form-item>
                            <el-form-item label="用户昵称" prop="nickname">
                                <el-input v-model="adminDetail.nickname" />
                            </el-form-item>
                            <el-form-item label="手机号码" prop="phone">
                                <el-input v-model="adminDetail.phone" maxlength="11" />
                            </el-form-item>
                            <el-form-item label="用户邮箱" prop="email">
                                <el-input v-model="adminDetail.email" maxlength="50" />
                            </el-form-item>
                            <el-form-item label="用户备注" prop="note">
                                <el-input v-model="adminDetail.note" />
                            </el-form-item>
                            <el-form-item>
                                <el-button type="primary" size="mini" @click="submitFirst">保存</el-button>
                                <el-button type="danger" size="mini" @click="closeFirst">关闭</el-button>
                            </el-form-item>
                        </el-form>
                    </el-tab-pane>
                    <el-tab-pane label="修改密码" name="second">
                        <el-form :model="updateForm" :rules="updateFormRules" ref="updateFormRefForm" label-width="80px">
                            <el-form-item label="旧密码" prop="password">
                                <el-input v-model="updateForm.password" placeholder="请输入旧密码" />
                            </el-form-item>
                            <el-form-item label="新密码" prop="newPassword">
                                <el-input v-model="updateForm.newPassword" placeholder="请输入新密码" />
                            </el-form-item>
                            <el-form-item label="确认密码" prop="resetPassword">
                                <el-input v-model="updateForm.resetPassword" placeholder="请确认密码" />
                            </el-form-item>
                            <el-form-item>
                                <el-button type="primary" size="mini" @click="submitSecond">保存</el-button>
                                <el-button type="danger" size="mini" @click="closeSecond">关闭</el-button>
                            </el-form-item>
                        </el-form>
                    </el-tab-pane>
                </el-tabs>
            </el-card>
        </el-col>
    </el-row>
</template>

<script>

import storage from '@/utils/storage' // 导入本地存储工具

export default {
    data() {
        return {
            adminDetail: storage.getItem("sysAdmin"), // 获取管理员详细信息
            activeName: 'first', // 设置默认选中的标签页
            uploadIconUrl: 'http://localhost:2002/api/upload', // 上传头像的接口地址
            headers: {
                Authorization: "Bearer " + storage.getItem("token"), // 设置请求头，包含身份验证的令牌
            },
            icon: '', // 用户头像的初始值
            editFormRules: { // 表单验证规则
                username: [{ required: true, message: '请输入用户账号', trigger: 'blur' }],
                email: [{ required: true, message: '请输入用户邮箱', trigger: 'blur' }],
                nickname: [{ required: true, message: '请输入用户昵称', trigger: 'blur' }],
                phone: [{ required: true, message: '请输入用户手机', trigger: 'blur' }],
                note: [{ required: true, message: '请输入用户备注', trigger: 'blur' }],
            },
            updateForm: { // 修改密码表单数据
                password: '',
                newPassword: '',
                resetPassword: ''
            },
            updateFormRules: { // 修改密码表单验证规则
                password: [{ required: true, message: '请输入旧密码', trigger: 'blur' }],
                newPassword: [{ required: true, message: '请输入新密码', trigger: 'blur' }],
                resetPassword: [{ required: true, message: '请输入重复密码', trigger: 'blur' }],
            }
        }
    },
    methods: {
        // 成功上传头像的回调函数
        handleAvatarSuccess(res, file) {
            this.icon = res.data; // 更新头像URL
        },
        // 提交修改个人信息的表单
        submitFirst() {
            this.$refs.editFormRefForm.validate(async valid => {
                if (!valid) return // 如果表单验证不通过，则终止操作
                const { data: res } = await this.$api.adminUpdatePersonal({
                    icon: this.icon === '' ? this.adminDetail.icon : this.icon, // 如果新头像未上传，使用原头像
                    username: this.adminDetail.username,
                    email: this.adminDetail.email,
                    nickname: this.adminDetail.nickname,
                    phone: this.adminDetail.phone,
                    note: this.adminDetail.note,
                })
                if (res.code !== 200) {
                    this.$message.error(res.message); // 如果接口返回错误，显示错误信息
                } else {
                    this.$storage.clearItem("sysAdmin") // 清除本地存储的旧管理员信息
                    this.$store.commit('saveSysAdmin', res.data) // 保存新的管理员信息到全局状态
                    await this.$router.push('/home') // 跳转到首页
                    this.$message.success('修改用户成功') // 显示成功信息
                }
            })
        },
        // 关闭修改个人信息表单
        closeFirst() {
            this.$router.push('/home') // 跳转到首页
        },
        // 提交修改密码的表单
        submitSecond() {
            this.$refs.updateFormRefForm.validate(async valid => {
                if (!valid) return // 如果表单验证不通过，则终止操作
                const { data: res } = await this.$api.adminUpdatePersonalPassword({
                    password: this.updateForm.password,
                    newPassword: this.updateForm.newPassword,
                    resetPassword: this.updateForm.resetPassword
                })
                if (res.code !== 200) {
                    this.$message.error(res.message); // 如果接口返回错误，显示错误信息
                } else {
                    this.$storage.clearAll() // 清除所有本地存储
                    this.$router.push("/login") // 跳转到登录页面
                    this.$message.success('修改密码成功') // 显示成功信息
                }
            })
        },
        // 关闭修改密码表单
        closeSecond() {
            this.$router.push('/home') // 跳转到首页
        }
    }
}

</script>

<style lang="less" scoped>
.el-avatar {
    height: 130px;
    width: 130px;
}

.avatar-uploader {
    border: 1px dashed #d9d9d9;
    border-radius: 6px;
    cursor: pointer;
    width: 50px;
    height: 50px;
    position: relative;
    overflow: hidden;

    .avatar {
        width: 50px;
        height: 50px;
        display: block;
    }
}
</style>