<template>
  <el-container class="home-container">
    <el-aside :width="isCollapse ? '64px' : '200px'">
      <div class="logo">
        <img src="./../assets/image/logo.jpg" class="sidebar-logo" />
        <h3 v-show="!isCollapse">通用后台管理系统</h3>
      </div>
      <el-menu unque-opened router :default-active="activePath" @select="handleSelect" background-color="#304156" text-color="#fff"
        unique-opened :collapse="isCollapse" :collapse-transition="false">
        <!--无子集菜单-->
        <el-menu-item :index="'/' + item.url" v-for="item in noChildren" :key="item.menuName">
          <i :class="item.icon"></i>
          <template slot="title">
            <span>{{ item.menuName }}</span>
          </template>
        </el-menu-item>
        <!--有子集菜单-->
        <el-submenu :index="item.id + ''" v-for="item in hasChildren" :key="item.id">
          <template slot="title">
            <i :class="item.icon"></i>
            <span>{{ item.menuName }}</span>
          </template>
          <el-menu-item :index="'/' + subItem.url" v-for="subItem in item.menuSvoList" :key="subItem.id">
            <template slot="title">
              <i :class="subItem.icon"></i>
              <span>{{ subItem.menuName }}</span>
            </template>
          </el-menu-item>
        </el-submenu>
      </el-menu>
    </el-aside>
    <el-container>
      <el-header class="header-container">
        <div class="fold-btn">
          <i :class="collapseBtnClass" @click="toggleCollapse"></i>
        </div>
        <div class="bread-btn">
          <el-breadcrumb separator="/" v-if="$router.currentRoute.path != '/welcome'">
            <el-breadcrumb-item :to="{ path: '/welcome' }">首页</el-breadcrumb-item>
            <el-breadcrumb-item>{{ $route.meta.sTitle }}</el-breadcrumb-item>
            <el-breadcrumb-item>{{ $route.meta.tTitle }}</el-breadcrumb-item>
          </el-breadcrumb>
          <el-breadcrumb separator="/" v-else>
            <el-breadcrumb-item :to="{ path: '/welcome' }">首页</el-breadcrumb-item>
          </el-breadcrumb>
        </div>
        <HeadImage></HeadImage><!-- /这个是Head组件 -->
      </el-header>
      <Tags/>
      <el-main>
        <router-view></router-view> <!-- 添加这个标签要这个标签实现组件开口 -->
      </el-main>
    </el-container>
  </el-container>
</template>

<script>
import storage from '@/utils/storage'
import HeadImage from "@/components/HeadImage"
import Tags from "@/components/Tags.vue"

export default {
  // eslint-disable-next-line vue/multi-word-component-names
  name: "Home",
  components: { HeadImage, Tags },

 
  data() {
  return {
    activePath: storage.getItem('activePath') || '', // 初始化 activePath
    leftMenuList: storage.getItem("leftMenuList") || [], // 确保 leftMenuList 是一个数组
    collapseBtnClass: "el-icon-s-fold",
    isCollapse: false,
  }
},

  computed: {
    // 无子菜单
    noChildren() {
      return this.leftMenuList.filter(item => !item.menuSvoList)
    },
    // 有子菜单
    hasChildren() {
      return this.leftMenuList.filter(item => item.menuSvoList)
    }
  },
  methods: {
    // 点击菜单项时触发
    handleSelect(index) {
      this.saveNavState(index);
      this.$router.push(index); // 触发路由跳转
    },
    // 保存导航状态
    saveNavState(activePath) {
      storage.setItem('activePath', activePath)
      this.activePath = activePath
    },
    // 展开和折叠侧边栏
    toggleCollapse() {
      this.isCollapse = !this.isCollapse
      if (this.isCollapse) {
        this.collapseBtnClass = 'el-icon-s-unfold'
      } else {
        this.collapseBtnClass = 'el-icon-s-fold'
      }
    }
  }
}
</script>

<style lang="less" scoped>
.home-container {
  height: 100%;

  .el-aside {
    .logo {
      margin-top: 5px;
      display: flex;
      align-items: center;
      font-size: 13px;
      height: 50px;
      color: #fff;
      font-style: italic;

      .sidebar-logo {
        width: 32px;
        height: 32px;
        margin: 0 16px;
      }
    }

    .el-menu {
      border-right: none;
    }

    background-color: #304156;
  }

  .header-container {
    display: flex;
    justify-content: space-between;
    align-items: center;
    background-color: #f9fafc;
    padding: 0 20px;

    .fold-btn {
      padding-top: 2px;
      font-size: 23px;
      cursor: pointer;
    }

    .bread-btn {
      flex-grow: 1;
      display: flex;
      justify-content:left;
    }
  }

  .el-main {
    background-color: #eaedf195;
  }
}
</style>
