<template>
    <el-card>
        <!--条件搜索区域-->
        <el-form :model="queryParams" :inline="true">
            <!-- 用户名称输入框 -->
            <el-form-item prop="username" label="用户名称">
                <el-input v-model="queryParams.username" placeholder="请输入用户名称" clearable size="mini"
                    @keyup.enter.native="handleQuery" />
            </el-form-item>
            <!-- 登录状态选择框 -->
            <el-form-item prop="loginStatus" label="登录状态">
                <el-select size="mini" placeholder="请选择岗位状态" v-model="queryParams.loginStatus">
                    <el-option v-for="item in loginStatusList" :key="item.value" :label="item.label" :value="item.value">
                    </el-option>
                </el-select>
            </el-form-item>
            <!-- 开始时间选择框 -->
            <el-form-item prop="beginTime" label="开始时间">
                <el-date-picker class="input-width" v-model="queryParams.beginTime" size="mini" type="date"
                    style="width: 190px" value-format="yyyy-MM-dd" clearable placeholder="请选择开始时间"
                    @keyup.enter.native="handleQuery"></el-date-picker>
            </el-form-item>
            <!-- 结束时间选择框 -->
            <el-form-item prop="endTime" label="结束时间">
                <el-date-picker class="input-width" v-model="queryParams.endTime" size="mini" type="date"
                    style="width: 190px" value-format="yyyy-MM-dd" clearable placeholder="请选择结束时间"
                    @keyup.enter.native="handleQuery"></el-date-picker>
            </el-form-item>
            <!-- 搜索和重置按钮 -->
            <el-form-item>
                <el-button type="primary" icon="el-icon-search" size="mini" @click="handleQuery">搜索</el-button>
                <el-button type="primary" icon="el-icon-refresh" size="mini" @click="resetQuery">重置</el-button>
            </el-form-item>
        </el-form>
        <!-- 操作按钮区域 -->
        <el-row :gutter="10" class="mb8">
            <!-- 批量删除按钮 -->
            <el-col :span="1.5">
                <el-button type="danger" plain icon="el-icon-delete" size="mini" :disabled="multiple"
                    @click="batchHandleDelete" v-authority="['monitor:loginLog:delete']">删除
                </el-button>
            </el-col>
            <!-- 清空按钮 -->
            <el-col :span="1.5">
                <el-button type="danger" plain icon="el-icon-delete" size="mini" @click="handleClean" v-authority="['monitor:loginLog:clean']">清空</el-button>
            </el-col>
        </el-row>
        <!-- 列表展示区域 -->
        <el-table v-loading="Loading" :data="sysLoginInfoList" border stripe style="width: 100%"
            :header-cell-style="{ background: '#eef1f6', color: '#606266' }" @selection-change="handleSelectionChange">
            <!-- 多选框列 -->
            <el-table-column type="selection" />
            <el-table-column label="ID" prop="id" v-if="false" />
            <el-table-column label="用户账号" prop="username" />
            <el-table-column label="登录IP地址" prop="ipAddress" />
            <el-table-column label="登录地点" prop="loginLocation" />
            <el-table-column label="浏览器类型" prop="browser" />
            <el-table-column label="操作系统" prop="os" />
            <!-- 登录状态列 -->
            <el-table-column label="登录状态" prop="loginStatus">
                <template slot-scope="scope">
                    <el-tag v-if="scope.row.loginStatus === 1" type="success">成功</el-tag>
                    <el-tag v-else-if="scope.row.loginStatus === 2" type="danger">失败</el-tag>
                </template>
            </el-table-column>
            <el-table-column label="提示消息" prop="message" />
            <el-table-column label="访问时间" prop="loginTime" />
            <!-- 更多操作列 -->
            <el-table-column label="更多操作">
                <template slot-scope="scope">
                    <!-- 删除按钮 -->
                    <el-button size="small" type="text" icon="el-icon-delete" @click="handleDelete(scope.row.id)" v-authority="['monitor:loginLog:delete']">删除
                    </el-button>
                </template>
            </el-table-column>
        </el-table>
        <!-- 分页区域 -->
        <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange"
            :current-page="queryParams.pageNum" :page-sizes="[10, 50, 100, 500, 1000]" :page-size="queryParams.pageSize"
            layout="total, sizes, prev, pager, next, jumper" :total="total">
        </el-pagination>
    </el-card>
</template>

<script>
export default {
    data() {
        return {
            queryParams: {}, // 查询参数对象
            loginStatusList: [{ // 登录状态选项列表
                value: '1',
                label: '成功'
            }, {
                value: '2',
                label: '失败'
            }],
            sysLoginInfoList: [], // 登录信息列表数据
            Loading: true, // 是否显示加载状态
            ids: [], // 选中的日志ID集合
            single: true, // 是否只选中单个日志
            multiple: true, // 是否选中多个日志
            total: 0, // 总数据条数
        }
    },
    methods: {
        // 多选框选中数据的处理
        handleSelectionChange(selection) {
            this.ids = selection.map(item => item.id); // 将选中的日志ID存入ids
            //map 方法： map 是 JavaScript 数组的一个方法，它会对数组中的每一个元素执行给定的回调函数，并返回一个新的数组。这个新数组包含了回调函数的返回值。
            this.single = selection.length != 1; // 是否单选
            this.multiple = !selection.length; // 是否有选中项
            //multiple是属性按键能否使用的属性
        },
        // 查询登录信息列表
        async getSysLoginInfoList() {
            this.Loading = true // 开始加载动画
            const { data: res } = await this.$api.querySysLoginInfoList(this.queryParams)
            if (res.code !== 200) {
                this.$message.error(res.message) // 请求失败提示错误信息
            } else {
                this.sysLoginInfoList = res.data.list // 设置登录信息列表数据
                this.total = res.data.total // 设置总数据条数
                this.Loading = false // 停止加载动画
            }
        },
        // 搜索按钮操作
        handleQuery() {
            this.getSysLoginInfoList(); // 触发查询
        },
        // 重置按钮操作
        resetQuery() {
            this.queryParams = {} // 重置查询参数
            this.getSysLoginInfoList(); // 重新查询
            this.$message.success("重置成功") // 显示重置成功的消息
        },
        // 修改分页大小
        handleSizeChange(newSize) {
            this.queryParams.pageSize = newSize // 更新每页显示数量
            this.getSysLoginInfoList() // 重新查询
        },
        // 修改当前页码
        handleCurrentChange(newPage) {
            this.queryParams.pageNum = newPage // 更新当前页码
            this.getSysLoginInfoList() // 重新查询
        },
        // 清空登录日志
        async handleClean() {
            const confirmResult = await this.$confirm('是否清空登录日志？', '提示', {
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                type: 'warning'
            }).catch(err => err)
            if (confirmResult !== 'confirm') {
                return this.$message.info('已取消') // 如果用户取消，提示取消信息
            }
            const { data: res } = await this.$api.cleanSysLoginInfo()
            if (res.code !== 200) {
                this.$message.error(res.message) // 清空失败提示错误信息
            } else {
                this.$message.success('清空成功') // 清空成功提示信息
                await this.getSysLoginInfoList() // 重新查询列表
            }
        },
        // 删除单个登录日志
        async handleDelete(id) {
            const confirmResult = await this.$confirm('是否确认删除登录日志编号为"' + id + '"的数据项？', '提示', {
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                type: 'warning'
            }).catch(err => err)
            if (confirmResult !== 'confirm') {
                return this.$message.info('已取消删除') // 如果用户取消，提示取消信息
            }
            const { data: res } = await this.$api.deleteSysLoginInfo(id)
            if (res.code !== 200) {
                this.$message.error(res.message) // 删除失败提示错误信息
            } else {
                this.$message.success('删除成功') // 删除成功提示信息
                await this.getSysLoginInfoList() // 重新查询列表
            }
        },
        // 批量删除登录日志
        async batchHandleDelete() {
            const loginInfoIds = this.ids; // 获取选中的日志ID集合
            const confirmResult = await this.$confirm('是否确认删除登录日志编号为"' + loginInfoIds + '"的数据项？', '提示', {
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                type: 'warning'
            }).catch(err => err)
            if (confirmResult !== 'confirm') {
                return this.$message.info('已取消删除') // 如果用户取消，提示取消信息
            }
            const { data: res } = await this.$api.batchDeleteSysLoginInfo(loginInfoIds)
            if (res.code !== 200) {
                this.$message.error(res.message) // 批量删除失败提示错误信息
            } else {
                this.$message.success('删除成功') // 批量删除成功提示信息
                await this.getSysLoginInfoList() // 重新查询列表
            }
        },
    },
    created() {
        this.getSysLoginInfoList() // 初始化时获取登录信息列表
    }
}
</script>

<style lang="less" scoped></style>
