<template>
    <el-card>
        <!--条件搜索区域-->
        <el-form :model="queryParams" :inline="true" v-show="showSearch">
            <el-form-item prop="username" label="用户名称">
                <el-input v-model="queryParams.username" placeholder="请输入用户名称" clearable size="mini"
                    @keyup.enter.native="handleQuery" />
            </el-form-item>
            <el-form-item prop="beginTime" label="开始时间">
                <el-date-picker class="input-width" v-model="queryParams.beginTime" size="mini" type="date"
                    style="width: 190px" value-format="yyyy-MM-dd" clearable placeholder="请选择开始时间"
                    @keyup.enter.native="handleQuery"></el-date-picker>
            </el-form-item>
            <el-form-item prop="endTime" label="结束时间">
                <el-date-picker class="input-width" v-model="queryParams.endTime" size="mini" type="date"
                    style="width: 190px" value-format="yyyy-MM-dd" clearable placeholder="请选择结束时间"
                    @keyup.enter.native="handleQuery"></el-date-picker>
            </el-form-item>
            <el-form-item>
                <el-button type="primary" icon="el-icon-search" size="mini" @click="handleQuery">搜索</el-button>
                <el-button type="primary" icon="el-icon-refresh" size="mini" @click="resetQuery">重置</el-button>
            </el-form-item>
        </el-form>
        <!--操作按钮-->
        <el-row :gutter="10" class="mb8">
            <el-col :span="1.5">
                <el-button type="danger" plain icon="el-icon-delete" size="mini" :disabled="multiple"
                    @click="batchHandleDelete" v-authority="['monitor:operator:delete']">删除
                </el-button>
            </el-col>
            <el-col :span="1.5">
                <el-button type="danger" plain icon="el-icon-delete" size="mini" @click="handleClean"
                    v-authority="['monitor:operator:clean']">清空</el-button>
            </el-col>
        </el-row>
        <!--列表区域-->
        <el-table v-loading="Loading" :data="sysOperationLogList" border stripe style="width: 100%"
            :header-cell-style="{ background: '#eef1f6', color: '#606266' }" @selection-change="handleSelectionChange">
            <el-table-column type="selection" />
            <el-table-column label="ID" prop="id" v-if="false" />
            <el-table-column label="用户账号" prop="username" />
            <el-table-column label="请求方式" prop="method" />
            <el-table-column label="登录IP" prop="Ip" />
            <el-table-column label="请求的URL" prop="Url" />
            <el-table-column label="操作时间" prop="createTime" />
            <el-table-column label="更多操作">
                <template slot-scope="scope">
                    <el-button size="small" type="text" icon="el-icon-delete" @click=handleDelete(scope.row.id)
                        v-authority="['monitor:operator:delete']">删除
                    </el-button>
                </template>
            </el-table-column>
        </el-table>
        <!--分页区域-->
        <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange"
            :current-page="queryParams.pageNum" :page-sizes="[10, 50, 100, 500, 1000]" :page-size="queryParams.pageSize"
            layout="total, sizes, prev, pager, next, jumper" :total="total">
        </el-pagination>
    </el-card>
</template>

<script>
export default {
    data() {
        return {
            Loading: true,               // 控制表格的加载状态，true 表示正在加载
            ids: [],                     // 存储选中操作日志的 ID 集合，用于批量操作
            single: true,                // 控制是否只选中了一条日志，用于控制按钮的状态
            multiple: true,              // 控制是否选中了多个日志，初始为 true 表示按钮禁用
            showSearch: true,            // 控制查询表单的显示与隐藏
            total: 0,                    // 数据总条数，用于分页控制
            queryParams: {},             // 查询参数对象，存储用户在查询表单中输入的内容
            sysOperationLogList: [],     // 操作日志数据列表，存储从后端获取的数据
        }
    },
    methods: {
        // 当用户在表格中选择或取消选择某些行时触发
        handleSelectionChange(selection) {
            this.ids = selection.map(item => item.id);  // 更新选中日志的 ID 集合
            this.single = selection.length != 1;        // 如果选中数量不等于 1，则禁用单条操作按钮
            this.multiple = !selection.length;          // 如果没有选中任何项，则禁用批量操作按钮
        },

        // 获取操作日志列表的方法，向后端发送查询请求
        async getSysOperationLogList() {
            this.Loading = true;  // 开始加载动画
            const { data: res } = await this.$api.querySysOperationLogList(this.queryParams);  // 发送请求，传入查询参数
            if (res.code !== 200) {
                this.$message.error(res.message);  // 请求失败时显示错误信息
            } else {
                this.sysOperationLogList = res.data.list;  // 请求成功时，更新操作日志列表
                this.total = res.data.total;  // 更新总条数，用于分页
                this.Loading = false;  // 停止加载动画
            }
        },

        // 处理搜索按钮点击事件，执行查询操作
        handleQuery() {
            this.getSysOperationLogList();  // 调用查询方法获取操作日志列表
        },

        // 处理重置按钮点击事件，清空查询表单并重新加载数据
        resetQuery() {
            this.queryParams = {};  // 重置查询参数对象
            this.getSysOperationLogList();  // 重新查询列表
            this.$message.success("重置成功");  // 显示重置成功的提示信息
        },

        // 处理每页显示数量变化的事件
        handleSizeChange(newSize) {
            this.queryParams.pageSize = newSize;  // 更新每页显示的数量
            this.getSysOperationLogList();  // 重新查询列表
        },

        // 处理当前页码变化的事件
        handleCurrentChange(newPage) {
            this.queryParams.pageNum = newPage;  // 更新当前页码
            this.getSysOperationLogList();  // 重新查询列表
        },

        // 处理清空操作日志的按钮点击事件
        async handleClean() {
            // 显示确认对话框，提示用户确认是否清空日志
            const confirmResult = await this.$confirm('是否清空操作日志？', '提示', {
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                type: 'warning'
            }).catch(err => err);
            
            if (confirmResult !== 'confirm') {
                return this.$message.info('已取消');  // 如果用户取消清空操作，显示提示信息
            }
            
            const { data: res } = await this.$api.cleanSysOperationLog();  // 发送清空日志请求
            if (res.code !== 200) {
                this.$message.error(res.message);  // 清空失败时显示错误信息
            } else {
                this.$message.success('清空成功');  // 清空成功时显示成功信息
                await this.getSysOperationLogList();  // 重新查询日志列表，刷新数据
            }
        },

        // 处理删除单个操作日志的按钮点击事件
        async handleDelete(id) {
            // 显示确认对话框，提示用户确认是否删除该日志
            const confirmResult = await this.$confirm('是否确认删除操作日志编号为"' + id + '"的数据项？', '提示', {
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                type: 'warning'
            }).catch(err => err);
            
            if (confirmResult !== 'confirm') {
                return this.$message.info('已取消删除');  // 如果用户取消删除操作，显示提示信息
            }
            
            const { data: res } = await this.$api.deleteSysOperationLog(id);  // 发送删除日志请求
            if (res.code !== 200) {
                this.$message.error(res.message);  // 删除失败时显示错误信息
            } else {
                this.$message.success('删除成功');  // 删除成功时显示成功信息
                await this.getSysOperationLogList();  // 重新查询日志列表，刷新数据
            }
        },

        // 处理批量删除操作日志的按钮点击事件
        async batchHandleDelete() {
            const sysOperationLogIds = this.ids;  // 获取选中的日志 ID 集合
            // 显示确认对话框，提示用户确认是否删除选中的日志
            const confirmResult = await this.$confirm('是否确认删除操作日志编号为"' + sysOperationLogIds + '"的数据项？', '提示', {
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                type: 'warning'
            }).catch(err => err);
            
            if (confirmResult !== 'confirm') {
                return this.$message.info('已取消删除');  // 如果用户取消删除操作，显示提示信息
            }
            
            const { data: res } = await this.$api.batchDeleteSysOperationLog(sysOperationLogIds);  // 发送批量删除日志请求
            if (res.code !== 200) {
                this.$message.error(res.message);  // 批量删除失败时显示错误信息
            } else {
                this.$message.success('删除成功');  // 批量删除成功时显示成功信息
                await this.getSysOperationLogList();  // 重新查询日志列表，刷新数据
            }
        },
    },

    // 在组件创建时，立即获取操作日志列表
    created() {
        this.getSysOperationLogList();  // 初始化时调用查询方法获取数据
    },
}

</script>

<style lang="less" scoped></style>