// eslint-disable-next-line vue/multi-word-component-names
<template>
  <el-card>
      <!--搜索-->
      <el-form :inline="true" :model="queryParams">
          <el-form-item label="角色名称" prop="roleName">
              <el-input placeholder="请输入角色名称" size="mini" clearable v-model="queryParams.roleName"
                  @keyup.enter.native="handleQuery"></el-input>
          </el-form-item>
          <el-form-item label="账号状态" prop="status">
              <el-select size="mini" placeholder="请选择账号状态" v-model="queryParams.status">
                  <el-option v-for="item in statusList" :key="item.value" :label="item.label" :value="item.value" />
              </el-select>
          </el-form-item>
          <el-form-item label="开始时间" prop="beginTime">
              <el-date-picker class="input-width" size="mini" type="date" style="width:190px" value-format="yyyy-MM-dd"
                  clearable placeholder="请选择开始时间" v-model="queryParams.beginTime" @keyup.enter.native="handleQuery" />
          </el-form-item>
          <el-form-item label="结束时间" prop="endTime">
              <el-date-picker class="input-width" size="mini" type="date" style="width:190px" value-format="yyyy-MM-dd"
                  clearable placeholder="请选择结束时间" v-model="queryParams.endTime" @keyup.enter.native="handleQuery" />
          </el-form-item>
          <el-form-item>
              <el-button type="primary" icon="el-icon-search" size="mini" @click="handleQuery">搜索</el-button>
              <el-button type="primary" icon="el-icon-refresh" size="mini" @click="resetQuery">重置</el-button>
          </el-form-item>
      </el-form>
      <!--操作按钮-->
      <el-row :gutter="10" class="mb8">
          <el-col :span="1.5">
              <el-button plain type="primary" icon="el-icon-plus" size="mini"
                  @click="addRoleDialogVisible = true" v-authority="['base:role:add']">新增</el-button>
                  <!-- 检查当前用户的权限是否包含 base:role:add。如果用户拥有这个权限，那么这个按钮会显示并且可以点击；如果没有权限，那么按钮可能会被隐藏或者禁用。 -->
          </el-col>
      </el-row>
      <!--列表-->
      <el-table v-loading="Loading" :data="roleList" border stripe style="width: 100%"
          :header-cell-style="{ background: '#eef1f6', color: '#606266' }">
          <!-- 。v-loading 指令的值通常是一个布尔值，当该值为 true 时，加载动画显示；当该值为 false 时，加载动画隐藏。 -->
          <el-table-column label="ID" prop="id" v-if="false" />
          <el-table-column label="角色名称" prop="roleName" />
          <el-table-column label="权限字符串" prop="roleKey" />
          <el-table-column label="创建时间" prop="createTime" />
          <el-table-column label="账号状态">
              <template slot-scope="scope">
                  <el-switch v-model="scope.row.status" :active-value="1" :inactive-value="2" active-color="#13ce66"
                      inactive-color="#F5222D" active-text="启用" inactive-text="停用" @change="roleUpdateStatus(scope.row)">
                  </el-switch>
              </template>
          </el-table-column>
          <el-table-column label="描述" prop="description" />
          <el-table-column label="更多操作">
              <template slot-scope="scope">
                  <el-button size="small" type="text" icon="el-icon-edit" @click="showEditRoleDialog(scope.row.id)" v-authority="['base:role:edit']">编辑
                  </el-button>
                  <el-button size="small" type="text" icon="el-icon-delete" @click="handleRoleDelete(scope.row)" v-authority="['base:role:delete']">删除
                  </el-button>
                  <el-button size="small" type="text" icon="el-icon-setting" @click="(scope.row)" v-authority="['base:role:assign']">分配权限
                  </el-button>
              </template>
          </el-table-column>
      </el-table>
      <!--分页区域-->
      <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange"
          :current-page="queryParams.pageNum" :page-sizes="[10, 50, 100, 500, 1000]" :page-size="queryParams.pageSize"
          layout="total, sizes, prev, pager, next, jumper" :total="total">
      </el-pagination>
      <!-- 新增角色                    语法糖双向绑定 -->
      <el-dialog title="新增角色" :visible.sync="addRoleDialogVisible" width="30%" @close="addRoleDialogClosed">
          <el-form ref="addRoleFormRefForm" label-width="80px" :model="addRoleForm" :rules="addRoleFormRules">
            <!-- ref 访问子组件实例  -->
            <el-form-item label="角色名称" prop="roleName">
                  <el-input placeholder="请输入角色名称" v-model="addRoleForm.roleName" />
              </el-form-item>
              <el-form-item label="角色标识" prop="roleKey">
                  <el-input placeholder="请输入角色标识" v-model="addRoleForm.roleKey" />
              </el-form-item>
              <el-form-item label="角色状态" prop="status">
                  <el-radio-group v-model="addRoleForm.status">
                      <el-radio :label="1">正常</el-radio>
                      <el-radio :label="2">停用</el-radio>
                  </el-radio-group>
              </el-form-item>
              <el-form-item label="角色描述" prop="description">
                  <el-input placeholder="请输入角色描述" type="textarea" v-model="addRoleForm.description" />
              </el-form-item>
          </el-form>
          <span slot="footer" class="dialog-footer">
              <el-button type="primary" @click="addRole">确 定</el-button>
              <el-button type="primary" @click="addRoleDialogVisible = false">取 消</el-button>
          </span>
      </el-dialog>
      <!--编辑角色-->
      <el-dialog title="编辑角色" :visible.sync="editRoleDialogVisible" width="30%" @close="editRoleDialogClosed">
        <!-- ref就是能访问下表单地数据   -->
        <el-form ref="editRoleFormRefForm" label-width="80px" :model="roleInfo" :rules="editRoleFormRules">
              <el-form-item label="角色名称" prop="roleName">
                  <el-input placeholder="请输入角色名称" v-model="roleInfo.roleName" />
              </el-form-item>
              <el-form-item label="角色标识" prop="roleKey">
                  <el-input placeholder="请输入角色标识" v-model="roleInfo.roleKey" />
              </el-form-item>
              <el-form-item label="角色状态" prop="status">
                  <el-radio-group v-model="roleInfo.status">
                      <el-radio :label="1">正常</el-radio>
                      <el-radio :label="2">停用</el-radio>
                  </el-radio-group>
              </el-form-item>
              <el-form-item label="角色描述" prop="status">
                  <el-input placeholder="请输入角色描述" type="textarea" v-model="roleInfo.description" />
              </el-form-item>
          </el-form>
          <span slot="footer" class="dialog-footer">
              <el-button type="primary" @click="editRole">确 定</el-button>
              <el-button type="primary" @click="editRoleDialogVisible = false">取 消</el-button>
          </span>
      </el-dialog>
      <!--分配权限-->
      <el-dialog title="分配权限" :visible.sync="setMenuDialogVisible" width="20%" @close="setRightDialogClosed">
          <el-tree :data="menuList" :props="treeProps" show-checkbox node-key="id" default-expand-all
              :default-checked-keys="defKeys" ref="treeRef">
          </el-tree>
          <span slot="footer" class="dialog-footer">
              <el-button type="primary" @click="allotMenus">确 定</el-button>
              <el-button type="primary" @click="setMenuDialogVisible = false">取 消</el-button>
          </span>
      </el-dialog>
  </el-card>
</template>

<script>
import Treeselect from "@riophae/vue-treeselect"  // 引入 Treeselect 组件
import "@riophae/vue-treeselect/dist/vue-treeselect.css"  // 引入 Treeselect 组件的样式

export default {
    components: { Treeselect },  // 注册 Treeselect 组件
    //Treeselect 组件注册到当前的 Vue 组件中。这意味着你可以在当前 Vue 组件的模板部分使用 <treeselect> 标签来实现树形选择框的功能。
    data() {  // 定义组件的数据
        return {
            statusList: [{  // 账号状态的选项列表
                value: '1',
                label: '启用'
            }, {
                value: '2',
                label: '停用'
            }],
            queryParams: {},  // 用于存储查询条件的对象
            Loading: false,  // 控制表格加载动画的布尔值
            roleList: [],  // 存储从服务器获取的角色列表数据
            total: 0,  // 总记录数，用于分页
            addRoleDialogVisible: false,  // 控制新增角色对话框的显示/隐藏
            addRoleForm: {  // 新增角色表单的数据对象 
                roleName: '',  // 角色名称
                roleKey: '',  // 角色标识
                description: '',  // 角色描述
                status: 1  // 角色状态，默认为启用
            },
            addRoleFormRules: {  // 新增角色表单的验证规则
                roleName: [{ required: true, message: '请输入角色名称', trigger: 'blur' }],
                roleKey: [{ required: true, message: '请角色权限标识', trigger: 'blur' }],
                status: [{ required: true, message: '请输入角色状态', trigger: 'blur' }],
                description: [{ required: true, message: '请输入角色描述', trigger: 'blur' }],
            },
            editRoleDialogVisible: false,  // 控制编辑角色对话框的显示/隐藏
            roleInfo: {},  // 存储要编辑的角色信息
            editRoleFormRules: {  // 编辑角色表单的验证规则
                roleName: [{ required: true, message: '请输入角色名称', trigger: 'blur' }],
                roleKey: [{ required: true, message: '请输入角色权限标识', trigger: 'blur' }],
                status: [{ required: true, message: '请输入角色状态', trigger: 'blur' }],
                description: [{ required: true, message: '请输入角色描述', trigger: 'blur' }],
            },
            setMenuDialogVisible: false,  // 控制分配权限对话框的显示/隐藏
            menuList: [],  // 存储从服务器获取的菜单列表数据，用于树形选择
            treeProps: {
                label: 'label'  // 树形选择框中显示节点的属性
            },
            defKeys: [],  // 存储已分配的菜单权限的 ID 列表
            id: '',  // 当前选中的角色 ID，用于分配权限时标识角色
        }
    },
    methods: {
        // 获取角色列表数据
        async getRoleList() {
            this.Loading = true  // 启用加载动画
            const { data: res } = await this.$api.queryRoleList(this.queryParams)  // 发起 API 请求获取角色列表数据
            if (res.code !== 200) {
                this.$message.error(res.message);  // 请求失败时显示错误消息
            } else {
                this.roleList = res.data.list  // 将获取到的数据赋值给 roleList
                this.total = res.data.total  // 更新总记录数
                this.Loading = false  // 停止加载动画
            }
        },
        // 搜索操作
        handleQuery() {
            this.getRoleList()  // 重新获取角色列表数据
        },
        // 重置查询条件
        resetQuery() {
            this.queryParams = {}  // 清空查询条件
            this.getRoleList()  // 重新获取角色列表数据 this.queryParams = {} 这一行代码的意思是将 queryParams 对象重新赋值为一个空对象，也就是清空原有的查询条件。
            this.$message.success("重置成功")  // 显示重置成功的提示消息
        },
        // 处理每页显示的记录数变更
        handleSizeChange(newSize) {
            this.queryParams.pageSize = newSize  // 更新 pageSize  
            this.getRoleList()  // 重新获取角色列表数据
        },
        // 处理当前页码变更
        handleCurrentChange(newPage) {
            this.queryParams.pageNum = newPage  // 更新 pageNum
            this.getRoleList()  // 重新获取角色列表数据
        },
        // 启用/停用角色
        async roleUpdateStatus(row) {
            let text = row.status === 2 ? "停用" : "启用"  // 判断操作类型
            const confirmResult = await this.$confirm(`确认要"${text}""${row.roleName}"角色吗?`, "警告", {
                confirmButtonText: "确定",
                cancelButtonText: "取消",
                type: "warning",
            }).catch(err => err)  // then就是确定的情况 catch是不确定的情况  
            //catch 方法捕获了 Promise 被拒绝时的错误（例如用户点击了“取消”按钮）。在这种情况下，confirmResult 的值将是 err，这通常用于区分用户是否确认了操作。
            //这一段代码中，someError 只是一个参数名，并不是固定的数据类型。它是用来接收 Promise 被拒绝时传递的错误对象。这个错误对象的类型取决于 Promise 失败的原因和上下文，因此 someError 可以是各种类型的数据。
            if (confirmResult !== 'confirm') {
                await this.getRoleList()  // 重新获取角色列表数据
                return this.$message.info('已取消删除')  // 显示取消操作的提示消息
            }
            await this.$api.updateRoleStatus(row.id, row.status)  // 发起 API 请求更新角色状态
            this.$message.success(text + "成功")  // 显示操作成功的提示消息
            await this.getRoleList()  // 重新获取角色列表数据
        },
        // 新增角色对话框关闭时重置表单
        addRoleDialogClosed() {
            this.$refs.addRoleFormRefForm.resetFields()  // 重置新增角色表单的所有字段
        },//：resetFields 方法用于将表单中的所有字段重
        //置为它们的初始值，通常在用户取消操作或需要清空表单时使用。
        // 新增角色
        addRole() {
            this.$refs.addRoleFormRefForm.validate(async valid => {  // 验证表单数据
                if (!valid) return  // 如果验证未通过，则终止操作
                const { data: res } = await this.$api.addRole(this.addRoleForm);  // 发起 API 请求提交新增角色数据
                if (res.code !== 200) {
                    this.$message.error(res.message);  // 如果请求失败，显示错误消息
                } else {
                    this.$message.success("新增角色成功")  // 显示新增成功的提示消息
                    this.addRoleDialogVisible = false  // 关闭新增角色对话框
                    await this.getRoleList()  // 重新获取角色列表数据
                }
            })
        },
        // 编辑角色对话框关闭时重置表单
        editRoleDialogClosed() {
            this.$refs.editRoleFormRefForm.resetFields()  // 重置编辑角色表单的所有字段
        },//这里重置的有哪些
        // 显示编辑角色对话框
        async showEditRoleDialog(id) {
            const { data: res } = await this.$api.roleInfo(id)  // 发起 API 请求获取角色信息
            if (res.code !== 200) {
                this.$message.error(res.message)  // 如果请求失败，显示错误消息
            } else {
                this.roleInfo = res.data  // 将获取到的角色信息赋值给 roleInfo
                this.editRoleDialogVisible = true  // 显示编辑角色对话框
            }
        },
        // 提交编辑角色表单
        editRole() {//this ref的对象.validate方法
            this.$refs.editRoleFormRefForm.validate(async valid => {  // 验证表单数据
                if (!valid) return  // 如果验证未通过，则终止操作
                const { data: res } = await this.$api.roleUpdate(this.roleInfo)  // 发起 API 请求提交编辑后的角色数据
                if (res.code !== 200) {
                    this.$message.error(res.message)  // 如果请求失败，显示错误消息
                } else {
                    this.editRoleDialogVisible = false  // 关闭编辑角色对话框
                    await this.getRoleList()  // 重新获取角色列表数据
                    this.$message.success("修改角色成功")  // 显示修改成功的提示消息
                }
            })
        },
        // 删除角色
        async handleRoleDelete(row) {
            const confirmResult = await this.$confirm(`是否确认删除角色为"${row.roleName}"的数据项？`, '提示', {
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                type: 'warning'
            }).catch(err => err)  // 显示确认对话框
            if (confirmResult !== 'confirm') {
                return this.$message.info('已取消删除')  // 如果用户取消操作，则显示取消提示消息
            }//？？？？？？？？？？
            const { data: res } = await this.$api.deleteRole(row.id)  // 发起 API 请求删除角色
            if (res.code !== 200) {
                this.$message.error(res.message)  // 如果请求失败，显示错误消息
            } else {
                this.$message.success('删除成功')  // 显示删除成功的提示消息
                await this.getRoleList()  // 重新获取角色列表数据
            }
        },
        // 显示分配菜单权限对话框
        showSetMenuDialog(role) {
            this.id = role.id  // 保存当前选中的角色 ID
            this.$api.querySysMenuVoList().then(res => {
                this.menuList = this.$handleTree.handleTree(res.data.data, "id")  // 获取菜单列表数据并转换为树形结构
            })
            this.$api.QueryRoleMenuIdList(role.id).then(res => {
                this.defKeys = res.data.data  // 获取已分配的菜单权限的 ID 列表
            })
            this.setMenuDialogVisible = true  // 显示分配权限对话框
        },
        // 分配权限对话框关闭时重置选项
        setRightDialogClosed() {
            this.defKeys = []  // 清空已分配的菜单权限的 ID 列表
        },
        // 提交分配的菜单权限
        async allotMenus() {
            const keys = [//使用 ... 展开运算符，可以将这两个数组中的所有元素展开，并合并成一个新的数组 keys。
                ...this.$refs.treeRef.getCheckedKeys(),  // 获取选中的节点 ID
                ...this.$refs.treeRef.getHalfCheckedKeys()  // 获取半选中的节点 ID
            ]
            const { data: res } = await this.$api.AssignPermissions(this.id, keys)  // 发起 API 请求提交分配的权限
            if (res.code !== 200) {
                this.$message.error(res.message)  // 如果请求失败，显示错误消息
            } else {
                this.$message.success('分配权限成功')  // 显示分配成功的提示消息
                await this.getRoleList()  // 重新获取角色列表数据
                this.setMenuDialogVisible = false  // 关闭分配权限对话框
            }
        }
    },
    created() {
        this.getRoleList()  // 组件创建时获取角色列表数据
    }
}
</script>


<style lang="less" scoped></style>