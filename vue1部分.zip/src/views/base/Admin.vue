<template>
    <el-card>
        <!--搜索区域-->
        <!-- inline 使表单变为行内表单 -->
        <el-form :inline="true" :model="queryParams">
            <el-form-item label="用户账号" prop="username">
                <el-input size="mini" placeholder="请输入用户账号" clearable v-model="queryParams.username"
                    @keyup.enter.native="handleQuery" />
                    <!-- clearable   使输入框具有可清除的功能。当用户输入文本后，会在输入框的右侧显示一个小的清除按钮，点击该按钮可以清除输入框中的内容。
                     监听 keyup 事件，当用户按下 Enter 键时，触发 handleQuery 方法。.native 修饰符表示直接监听原生 DOM 事 -->
            </el-form-item>
            <el-form-item label="账号状态" prop="status">
                <el-select size="mini" placeholder="请选择账号状态" v-model="queryParams.status">
                    <el-option v-for="item in statusList" :key="item.value" :label="item.label"
                        :value="item.value"></el-option>
                </el-select>
            </el-form-item>
            <el-form-item label="开始时间" prop="beginTime">
                <el-date-picker class="input-width" size="mini" type="date" style="width: 190px" value-format="yyyy-MM-dd"
                    clearable placeholder="请选择开始时间" v-model="queryParams.beginTime" @keyup.enter.native="handleQuery" />
            </el-form-item>
            <el-form-item label="结束时间">
                <el-date-picker class="input-width" size="mini" type="date" style="width: 190px" value-format="yyyy-MM-dd"
                    clearable placeholder="请选择结束时间" v-model="queryParams.endTime" @keyup.enter.native="handleQuery" />
            </el-form-item>
            <el-form-item>
                <el-button type="primary" icon="el-icon-search" size="mini" @click="handleQuery">搜索</el-button>
                <el-button type="primary" icon="el-icon-refresh" size="mini" @click="resetQuery">重置</el-button>
            </el-form-item>
            <!--操作按钮-->
            <el-row :gutter="10" class="mb8">
                <el-col :span="1.5">
                    <el-button plain type="primary" icon="el-icon-plus" size="mini"
                        @click="addDialogVisible = true" v-authority="['base:admin:add']">新增</el-button>
                    <!--  v-authority 是用于权限控制的自定义指令。它通常用于 Vue.js 项目中来控制用户是否可以看到或使用某些组件或功能。 -->
                </el-col>
            </el-row>
            <!--列表-->
            <el-table v-loading="Loading" :data="adminList" border stripe style="width: 100%"
                :header-cell-style="{ background: '#eef1f6', color: '#606266' }">
                <el-table-column label="ID" prop="id" v-if="false" />
                <el-table-column label="用户账号" prop="username" />
                <el-table-column label="用户昵称" prop="nickname" />
                <el-table-column label="用户手机" prop="phone" width="120" />
                <el-table-column label="用户邮箱" prop="email" width="170" />
                <el-table-column label="用户头像" prop="icon">
                    <template slot-scope="scope">
                        <el-avatar shape="circle" :src="scope.row.icon"></el-avatar>
                        <!-- el-avatar 是 Element UI 中的头像组件，用于显示用户头像或其他图片
                         shape 属性可以控制头像的形状  
                         size 属性用来设置头像的大小。       -->
                    </template>
                </el-table-column>
                <el-table-column label="创建时间" prop="createTime" width="160" />
                <el-table-column label="账号状态" width="150">
                    <template slot-scope="scope">
                        <el-switch v-model="scope.row.status" :active-value="1" :inactive-value="2" active-color="#13ce66"
                            inactive-color="#F5222D" active-text="启用" inactive-text="停用"
                            @change="adminUpdateStatus(scope.row)">
                        </el-switch>
                    </template>
                </el-table-column>
                <el-table-column label="部门/岗位" width="180">
                    <template slot-scope="scope">
                        <!-- 每一行的的postName属性 -->
                        <div>{{ scope.row.deptName }} / {{ scope.row.postName }}</div>
                        <!-- scope.row 指向当前行的数据对象。scope.row 实际上就是 adminList 数组中的某个元素。 -->
                    </template>
                </el-table-column>
                <el-table-column label="角色名称" prop="roleName">
                    <template slot-scope="scope">
                        <el-tag type="success">{{ scope.row.roleName }}</el-tag>
                        <!-- 用于将 JavaScript 表达式的结果插入到 HTML 模板中。 -->
                    </template>
                </el-table-column>
                <el-table-column label="个人简介" prop="note" />
                <el-table-column label="更多操作" fixed="right" width="200">
                    <template slot-scope="scope">
                        <el-button size="small" type="text" icon="el-icon-edit"
                            @click="showEditAdminDialog(scope.row.id)" v-authority="['base:admin:edit']">编辑
                        </el-button>
                        <el-button size="small" type="text" icon="el-icon-delete" @click="handleAdminDelete(scope.row)" v-authority="['base:admin:delete']">删除
                        </el-button>
                        <el-button size="small" type="text" icon="el-icon-key" @click="handleResetPwd(scope.row)" v-authority="['base:admin:reset']">重置密码
                        </el-button>
                    </template>
                </el-table-column>
            </el-table>
            <!--分页区域-->
            <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange"
                :current-page="queryParams.pageNum" :page-sizes="[10, 50, 100, 500, 1000]" :page-size="queryParams.pageSize"
                layout="total, sizes, prev, pager, next, jumper" :total="total">
            </el-pagination>
        </el-form>
        <!-- 添加用户 -->
        <el-dialog title="新增用户" :visible.sync="addDialogVisible" width="40%" @close="addDialogClosed">
            <el-form :model="addForm" :rules="addFormRules" ref="addFormRefForm" label-width="80px">
                <el-row>
                    <el-col :span="12">
                        <el-form-item label="用户昵称" prop="nickname">
                            <el-input v-model="addForm.nickname" placeholder="请输入用户昵称" maxlength="30" />
                        </el-form-item>
                    </el-col>
                    <el-col :span="12">
                        <el-form-item size="mini" label="归属部门" prop="deptId">
                            <treeselect v-model="addForm.deptId" :options="deptList" :show-count="true"
                                placeholder="请选择归属部门" />
                                <!-- treeselect 组件会在选项标签旁边显示当前选中的项的数量 -->
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-row>
                    <el-col :span="12">
                        <el-form-item label="手机号码" prop="phone">
                            <el-input v-model="addForm.phone" placeholder="请输入手机号码" maxlength="11" />
                        </el-form-item>
                    </el-col>
                    <el-col :span="12">
                        <el-form-item label="用户邮箱" prop="email">
                            <el-input v-model="addForm.email" placeholder="请输入邮箱" maxlength="50" />
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-row>
                    <el-col :span="12">
                        <el-form-item label="用户名称" prop="username">
                            <el-input v-model="addForm.username" placeholder="请输入用户名称" maxlength="30" />
                        </el-form-item>
                    </el-col>
                    <el-col :span="12">
                        <el-form-item label="用户密码" prop="password">
                            <el-input v-model="addForm.password" placeholder="请输入用户密码" type="password" maxlength="20"
                                show-password />
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-row>
                    <el-col :span="12">
                        <el-form-item label="用户状态" prop="status">
                            <el-radio-group v-model="addForm.status">
                                <el-radio :label="1">正常</el-radio>
                                <el-radio :label="2">停用</el-radio>
                            </el-radio-group>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-row>
                    <el-col :span="12">
                        <el-form-item label="用户岗位" prop="postId">
                            <el-select placeholder="请选择岗位" v-model="addForm.postId">
                                <el-option v-for="item in postList" :key="item.id" :label="item.postName" :value="item.id">
                                </el-option>
                            </el-select>
                        </el-form-item>
                    </el-col>
                    <el-col :span="12">
                        <el-form-item label="用户角色" prop="roleId">
                            <el-select placeholder="请选择角色" v-model="addForm.roleId">
                                <el-option v-for="item in roleList" :key="item.id" :label="item.roleName"
                                    :value="item.id"></el-option>
                            </el-select>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-row>
                    <el-col :span="24">
                        <el-form-item label="个人简介" prop="note">
                            <el-input v-model="addForm.note" type="textarea" placeholder="请输入内容"></el-input>
                        </el-form-item>
                    </el-col>
                </el-row>
            </el-form>
            <span slot="footer" class="dialog-footer">
                <el-button type="primary" @click="addAdmin">确 定</el-button>
                <el-button type="primary" @click="addDialogVisible = false">取 消</el-button>
            </span>
        </el-dialog>
        <!--修改用户-->
        <el-dialog title="修改用户" :visible.sync="editDialogVisible" width="40%" @close="editDialogClosed">
            <el-form :model="adminInfo" :rules="editFormRules" ref="editFormRefForm" label-width="80px">
                <el-row>
                    <el-col :span="12">
                        <el-form-item label="用户昵称" prop="nickname">
                            <el-input v-model="adminInfo.nickname" placeholder="请输入用户昵称" maxlength="30" />
                        </el-form-item>
                    </el-col>
                    <el-col :span="12">
                        <el-form-item size="mini" label="归属部门" prop="deptId">
                            <treeselect v-model="adminInfo.deptId" :options="deptList" :show-count="true"
                                placeholder="请选择归属部门" />
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-row>
                    <el-col :span="12">
                        <el-form-item label="手机号码" prop="phone">
                            <el-input v-model="adminInfo.phone" placeholder="请输入手机号码" maxlength="11" />
                        </el-form-item>
                    </el-col>
                    <el-col :span="12">
                        <el-form-item label="用户邮箱" prop="email">
                            <el-input v-model="adminInfo.email" placeholder="请输入邮箱" maxlength="50" />
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-row>
                    <el-col :span="12">
                        <el-form-item label="用户名称" prop="username">
                            <el-input v-model="adminInfo.username" placeholder="请输入用户名称" maxlength="30" />
                        </el-form-item>
                    </el-col>
                    <el-col :span="12">
                        <el-form-item label="用户状态" prop="status">
                            <el-radio-group v-model="adminInfo.status">
                                <el-radio :label="1">正常</el-radio>
                                <el-radio :label="2">停用</el-radio>
                            </el-radio-group>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-row>
                    <el-col :span="12">
                        <el-form-item label="用户岗位" prop="postId">
                            <el-select placeholder="请选择岗位" v-model="adminInfo.postId">
                                <el-option v-for="item in postList" :key="item.id" :label="item.postName" :value="item.id">
                                </el-option>
                            </el-select>
                        </el-form-item>
                    </el-col>
                    <el-col :span="12">
                        <el-form-item label="用户角色" prop="roleId">
                            <el-select placeholder="请选择角色" v-model="adminInfo.roleId">
                                <el-option v-for="item in roleList" :key="item.id" :label="item.roleName"
                                    :value="item.id"></el-option>
                            </el-select>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-row>
                    <el-col :span="24">
                        <el-form-item label="个人简介" prop="note">
                            <el-input v-model="adminInfo.note" type="textarea" placeholder="请输入内容"></el-input>
                        </el-form-item>
                    </el-col>
                </el-row>
            </el-form>
            <span slot="footer" class="dialog-footer">
                <el-button type="primary" @click="editAdminInfo">确 定</el-button>
                <el-button type="primary" @click="editDialogVisible = false">取 消</el-button>
            </span>
        </el-dialog>
    </el-card>
</template>

<script>
import Treeselect from "@riophae/vue-treeselect"
import "@riophae/vue-treeselect/dist/vue-treeselect.css"

export default {
    components: { Treeselect },
    data() {
        return {
            statusList: [{
                value: '1',
                label: '启用', // 状态为启用
            }, {
                value: '2',
                label: '停用', // 状态为停用
            }],
            Loading: false, // 加载状态
            queryParams: {}, // 查询参数
            adminList: [], // 用户列表
            total: 0, // 用户总数
            addDialogVisible: false, // 控制新增用户对话框的显示
            deptList: [], // 部门列表
            roleList: [], // 角色列表
            postList: [], // 岗位列表
            addForm: { // 新增用户表单数据
                username: '',
                password: '',
                deptId: undefined,
                postId: undefined,
                roleId: undefined,
                email: '',
                nickname: '',
                status: 1, // 默认状态为启用
                phone: '',
                note: ''
            },
            addFormRules: { // 新增用户表单验证规则
                deptId: [{ required: true, message: '请选择部门', trigger: 'blur' }],
                postId: [{ required: true, message: '请选择岗位', trigger: 'blur' }],
                roleId: [{ required: true, message: '请选择角色', trigger: 'blur' }],
                username: [{ required: true, message: '请输入用户账号', trigger: 'blur' }],
                password: [{ required: true, message: '请输入用户密码', trigger: 'blur' }],
                status: [{ required: true, message: '请选择状态', trigger: 'blur' }],
                email: [{ required: true, message: '请输入用户邮箱', trigger: 'blur' }],
                nickname: [{ required: true, message: '请输入用户昵称', trigger: 'blur' }],
                phone: [{ required: true, message: '请输入用户手机', trigger: 'blur' }]
            },
            editDialogVisible: false, // 控制编辑用户对话框的显示
            adminInfo: {}, // 编辑用户时的用户信息
            editFormRules: { // 编辑用户表单验证规则
                deptId: [{ required: true, message: '请选择部门', trigger: 'blur' }],
                postId: [{ required: true, message: '请选择岗位', trigger: 'blur' }],
                roleId: [{ required: true, message: '请选择角色', trigger: 'blur' }],
                username: [{ required: true, message: '请输入用户账号', trigger: 'blur' }],
                status: [{ required: true, message: '请选择状态', trigger: 'blur' }],
                email: [{ required: true, message: '请输入用户邮箱', trigger: 'blur' }],
                nickname: [{ required: true, message: '请输入用户昵称', trigger: 'blur' }],
                phone: [{ required: true, message: '请输入用户手机', trigger: 'blur' }]
            },

        }
    },
    methods: {
        // 查询用户列表
        async getAdminList() {
            this.Loading = true
            const { data: res } = await this.$api.queryAdminList(this.queryParams)
            if (res.code !== 200) {
                this.$message.error(res.message) // 如果查询失败，显示错误信息
            } else {
                this.adminList = res.data.list // 更新用户列表
                this.total = res.data.total // 更新用户总数
                this.Loading = false // 关闭加载状态
            }
        },
        // 点击搜索按钮的操作
        handleQuery() {
            this.getAdminList(); // 调用查询用户列表方法
        },
        // 点击重置按钮的操作
        resetQuery() {
            this.queryParams = {} // 重置查询参数
            this.getAdminList(); // 重新查询用户列表
            this.$message.success("重置成功") // 显示重置成功的消息
        },
        // 修改每页显示的用户数量
        handleSizeChange(newSize) {
            this.queryParams.pageSize = newSize // 更新每页显示数量
            this.getAdminList() // 重新查询用户列表
        },
        // 修改当前页码
        handleCurrentChange(newPage) {
            this.queryParams.pageNum = newPage // 更新当前页码
            this.getAdminList() // 重新查询用户列表
        },
        // 修改用户状态（启用或停用）
        async adminUpdateStatus(row) {
            let text = row.status === 2 ? "停用" : "启用"; // 根据状态设置文本
            const confirmResult = await this.$confirm('确认要"' + text + '""' + row.username + '"用户吗?', "警告", {
                confirmButtonText: "确定",
                cancelButtonText: "取消",
                type: "warning",
            }).catch(err => err)
            if (confirmResult !== 'confirm') {
                await this.getAdminList() // 重新查询用户列表
                return this.$message.info('已取消删除')
            }
            this.$api.updateAdminStatus(row.id, row.status) // 更新用户状态
            this.$message.success(text + "成功") // 显示操作成功的消息
            await this.getAdminList() // 重新查询用户列表
        },
        // 获取部门列表
        async getDeptVoList() {
            const { data: res } = await this.$api.querySysDeptVoList()
            if (res.code !== 200) {
                this.$message.error(res.message) // 如果获取失败，显示错误信息
            } else {
                this.deptList = this.$handleTree.handleTree(res.data, "id"); // 处理树形结构的部门列表
            }
        },
        // 获取角色列表
        async getRoleVoList() {
            const { data: res } = await this.$api.querySysRoleVoList()
            if (res.code !== 200) {
                this.$message.error(res.message) // 如果获取失败，显示错误信息
            } else {
                this.roleList = res.data // 更新角色列表
            }
        },
        // 获取岗位列表
        async getPostVoList() {
            const { data: res } = await this.$api.querySysPostVoList()
            if (res.code !== 200) {
                this.$message.error(res.message) // 如果获取失败，显示错误信息
            } else {
                this.postList = res.data // 更新岗位列表
            }
        },
        // 监听添加用户对话框关闭事件
        addDialogClosed() {
            this.$refs.addFormRefForm.resetFields() // 重置新增用户表单
            // resetFields() 是 Element UI 中表单组件（el-form）的一个方法。它用于重置表单的字段，将表单的所有输入值恢复到初始状态，并清除验证信息。
        },
        // 新增用户
        addAdmin() {
            this.$refs.addFormRefForm.validate(async valid => {
                if (!valid) return
                const { data: res } = await this.$api.addAdmin(this.addForm);
                if (res.code !== 200) {
                    this.$message.error(res.message) // 如果新增失败，显示错误信息
                } else {
                    this.$message.success('新增用户成功') // 显示新增成功的消息
                    this.addDialogVisible = false // 关闭对话框
                    await this.getAdminList() // 重新查询用户列表
                }
            })
        },
        // 显示编辑用户的对话框
        async showEditAdminDialog(id) {
            const { data: res } = await this.$api.adminInfo(id)
            if (res.code !== 200) {
                this.$message.error(res.message) // 如果获取用户信息失败，显示错误信息
            } else {
                this.adminInfo = res.data // 更新用户信息
                this.editDialogVisible = true // 显示编辑用户对话框
            }
        },
        // 监听修改用户对话框的关闭事件
        editDialogClosed() {
            this.$refs.editFormRefForm.resetFields() // 重置编辑用户表单
        },
        // 修改用户信息并提交
        editAdminInfo() {
            this.$refs.editFormRefForm.validate(async valid => {
                if (!valid) return
                const { data: res } = await this.$api.adminUpdate(this.adminInfo)
                if (res.code !== 200) {
                    this.$message.error(res.message) // 如果修改失败，显示错误信息
                } else {
                    this.editDialogVisible = false // 关闭对话框
                    await this.getAdminList() // 重新查询用户列表
                    this.$message.success('修改用户成功') // 显示修改成功的消息
                }
            })
        },
        // 删除用户
        async handleAdminDelete(row) {
            const confirmResult = await this.$confirm('是否确认删除用户为"' + row.username + '"的数据项？', '提示', {
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                type: 'warning'
            }).catch(err => err)
            if (confirmResult !== 'confirm') {
                return this.$message.info('已取消删除')
            }
            const { data: res } = await this.$api.deleteAdmin(row.id)
            if (res.code !== 200) {
                this.$message.error(res.message) // 如果删除失败，显示错误信息
            } else {
                this.$message.success('删除成功') // 显示删除成功的消息
                await this.getAdminList() // 重新查询用户列表
            }
        },
        // 重置密码
        handleResetPwd(row) {
            this.$prompt('请输入"' + row.username + '"的新密码', "提示", {
                confirmButtonText: "确定",
                cancelButtonText: "取消",
                closeOnClickModal: false,
                /*  属性设置 closeOnClickModal:
              类型: 布尔值（true 或 false）。
               默认值: true，表示点击模态背景会关闭弹出框。*/
                inputPattern: /^.{5,20}$/,
                inputErrorMessage: "用户密码长度必须介于 5 和 20 之间"
            }).then(({ value }) => {
                this.$api.resetPassword(row.id, value).then(response => {
                    this.$message.success("修改成功，新密码是：" + value); // 显示修改密码成功的消息
                });
            }).catch(() => {
            });//点取消啥也不干
        }
    },
    created() {
        this.getAdminList() // 初始化时获取用户列表
        this.getDeptVoList() // 初始化时获取部门列表
        this.getRoleVoList() // 初始化时获取角色列表
        this.getPostVoList() // 初始化时获取岗位列表
    }
}

</script>
<style lang="less" scoped></style>