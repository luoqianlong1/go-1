<template>
  <el-card>
    <!-- 搜索区域 -->
    <el-form :inline="true" :model="queryParams">
      <el-form-item label="部门名称">
        <el-input placeholder="请输入部门名称" clearable size="mini" v-model="queryParams.deptName" />
      </el-form-item>
      <el-form-item label="部门状态">
        <el-select placeholder="请选择部门状态" size="mini" v-model="queryParams.deptStatus">
          <el-option v-for="item in deptStatusList" :key="item.value" :label="item.label" :value="item.value" />
        </el-select>
      </el-form-item>
      <el-form-item>
        <el-button type="primary" icon="el-icon-search" size="mini" @click="handleQuery">搜索</el-button>
        <el-button type="primary" icon="el-icon-refresh" size="mini" @click="resetQuery">重置</el-button>
      </el-form-item>
    </el-form>

    <!-- 操作按钮 -->
    <el-row :gutter="10" class="mb8">
      <el-col :span="1.5">
        <el-button type="primary" plain icon="el-icon-plus" size="mini" @click="addDeptDialogVisible = true">新增</el-button>
      </el-col> <!-- addDeptDialogVisible 变量设置为 true。 -->
      <el-col :span="1.5">
        <el-button type="info" plain icon="el-icon-sort" size="mini" @click="toggleExpandAll">展开/折叠</el-button>
      </el-col>
    </el-row>

    <!-- 列表 -->
    <el-table border stripe :header-cell-style="{ background: '#eef1f6', color: '#606266' }" v-if="refreshTable" v-loading="loading" :data="deptList" row-key="id" :default-expand-all="isExpandAll" :tree-props="{ children: 'children' }">
      <!-- border 边框 tripe: 为表格添加斑马条纹效果                                                                   显示加载动画的指令      表格中每一行数据的唯一标识字段。   制表格中的树形节点是否默认全部展开      如果数据项中包含一个 children 数组，这些子数据项会在父数据项下作为子节点显示           -->
      <el-table-column label="部门名称" prop="deptName" />
      <el-table-column label="部门类型" prop="deptType">
        <template slot-scope="scope">
          <el-tag v-if="scope.row.deptType === 1">公司</el-tag>
          <el-tag v-else-if="scope.row.deptType === 2" type="success">中心</el-tag>
          <el-tag v-else-if="scope.row.deptType === 3" type="danger">部门</el-tag>
        </template>
      </el-table-column>
      <el-table-column label="部门状态" prop="deptStatus">
        <template slot-scope="scope">
          <el-tag v-if="scope.row.deptStatus === 1" type="success">正常</el-tag>
          <el-tag v-else-if="scope.row.deptStatus === 2" type="danger">停用</el-tag>
        </template>
      </el-table-column>
      <el-table-column label="创建时间" prop="createTime" />
      <el-table-column label="更多操作" class-name="small-padding fixed width">
        <template slot-scope="scope">
          <el-button size="mini" type="text" icon="el-icon-edit" @click="showEditDeptDialog(scope.row.id)">修改</el-button>
          <el-button size="mini" type="text" icon="el-icon-delete" @click="handleDeptDelete(scope.row)" :disabled="scope.row.deptType == '1'">删除</el-button>
        </template>
      </el-table-column>
    </el-table>


                                <!-- 就是能不能显示 bool值展示 -->
    <el-dialog title="新增部门" :visible.sync="addDeptDialogVisible" width="30%" @close="addDeptDialogClosed">
    <el-form :model="addDeptForm" :rules="addDeptFormRules" ref="addDeptFormRefForm" label-width="80px">
      <el-form-item label="部门类型" prop="deptType">
        <el-radio-group v-model="addDeptForm.deptType">
          <el-radio :label="1">公司</el-radio>
          <el-radio :label="2">中心</el-radio>
          <el-radio :label="3">部门</el-radio>
        </el-radio-group>
      </el-form-item>
      <el-form-item size="mini" label="上级部门" prop="parentId" v-if="addDeptForm.deptType != 1">
        <treeselect :options="optionsDeptList" placeholder="请选择上级部门" v-model="addDeptForm.parentId" />
        <!-- optionsDeptList: 指定了的可选项数据。optionsDeptList 是一个数组，包含了树形结构的选项数据。 -->
      </el-form-item>
      <el-form-item label="部门名称" prop="deptName">
        <el-input v-model="addDeptForm.deptName" placeholder="请输入部门名称" />
      </el-form-item>
      <el-form-item label="部门状态" prop="deptStatus">
        <el-radio-group v-model="addDeptForm.deptStatus">
          <el-radio :label="1">正常</el-radio>
          <el-radio :label="2">停用</el-radio>
        </el-radio-group>
      </el-form-item>
      <el-form-item label="部门描述" prop="remark">
        <el-input type="textarea" v-model="addDeptForm.remark" placeholder="请输入部门描述" />
      </el-form-item>
    </el-form>
    <span slot="footer" class="dialog-footer">
      <el-button type="primary" @click="addDept">确定</el-button>
      <el-button type="primary" @click="addDeptDialogVisible = false">取消</el-button>
    </span>
  </el-dialog>





  </el-card>
</template>

<script>
import Treeselect from '@riophae/vue-treeselect';
import '@riophae/vue-treeselect/dist/vue-treeselect.css';

export default {
  components: { Treeselect },
  data() {
    return {
      // 部门状态选项列表
      deptStatusList: [
        { value: '2', label: '停用' },
        { value: '1', label: '正常' }
      ],
      // 查询参数对象，用于存储搜索条件
      queryParams: {},
      // 控制表格加载状态
      loading: true,
      // 控制表格刷新状态
      refreshTable: true,
      // 控制是否展开所有树节点
      isExpandAll: true,
      // 存储部门列表数据
      deptList: [],
      // 控制新增部门对话框的显示与隐藏
      addDeptDialogVisible: false,
      // 存储部门下拉列表数据
      optionsDeptList: [],
      // 控制编辑部门对话框的显示与隐藏
      editDeptDialogVisible: false,
      // 存储部门信息，用于编辑
      deptInfo: {},
      // 编辑部门表单验证规则
      editDeptFormRules: {
        deptType: [{ required: true, message: '请选择部门类型', trigger: 'blur' }],
        deptName: [{ required: true, message: '请输入部门名称', trigger: 'blur' }]
      },
    /*  
    deptName：这个字段对应表单中的部门名称字段。
   required: true：表示这个字段是必填的，用户必须输入部门名称。
   message: '请输入部门名称'：这是验证失败时的提示信息。如果用户没有输入部门名称，表单验证会失败，并显示这条消息。
t    rigger: 'blur'：表示触发验证的事件是 blur，即当用户离开输入框时（失去焦点时），会触发验证。*/
      // 新增部门表单数据对象
      addDeptForm: {
        deptType: '',
        parentId: '',
        deptName: '',
        deptStatus: 1,
        remark: ''
      }
    };
  },
  methods: {
    // 获取部门列表数据
    async getList() {
      this.loading = true; // 开启加载状态
      const { data: res } = await this.$api.queryDeptList(this.queryParams); // 发送 API 请求，获取部门列表数据
      if (res.code !== 200) { // 如果请求失败
        this.$message.error(res.message); // 显示错误消息
      } else {
        this.deptList = this.$handleTree.handleTree(res.data, 'id'); // 处理数据为树状结构
      //handleTree组件中的,handleTree函数  平铺的数据列表转换为树状结构
        this.loading = false; // 关闭加载状态
      }
    },
    // 搜索部门
    handleQuery() {
      this.getList(); // 调用 getList 方法，根据当前查询条件获取部门列表
    },
    // 重置搜索条件
    resetQuery() {
      this.queryParams = {}; // 清空查询条件
      this.getList(); // 重新获取部门列表数据
      this.$message.success('重置成功'); // 显示重置成功的提示消息
    },
    // 切换部门树的展开和折叠状态
    toggleExpandAll() {
      this.refreshTable = false; // 临时禁用表格渲染，以便切换展开状态
      this.isExpandAll = !this.isExpandAll; // 切换展开/折叠状态
      this.$nextTick(() => {
        this.refreshTable = true; // 重新启用表格渲染
      });
    },
    // 获取上级部门的下拉列表数据
    async getDeptVoList() {
      const { data: res } = await this.$api.querySysDeptVoList(); // 发送 API 请求，获取上级部门列表
      if (res.code !== 200) { // 如果请求失败
        this.$message.error(res.message); // 显示错误消息
      } else {
        this.optionsDeptList = this.$handleTree.handleTree(res.data, 'id'); // 处理数据为树状结构，存储为下拉列表选项
      }
    },
    // 监听新增部门对话框关闭事件，重置表单
    addDeptDialogClosed() {
      //函数重置表单
      this.$refs.addDeptFormRefForm.resetFields(); // 重置新增部门表单中的所有字段
    },
    // 提交新增部门表单数据
    addDept() {
      this.$refs.addDeptFormRefForm.validate(async valid => { // 验证表单数据
        if (!valid) return; // 如果验证未通过，终止操作
        const { data: res } = await this.$api.addDept(this.addDeptForm); // 发送 API 请求，提交新增的部门数据
        if (res.code !== 200) { // 如果请求失败
          this.$message.error(res.message); // 显示错误消息
        } else {
          this.$message.success('新增部门成功'); // 显示新增成功的提示消息
          this.addDeptDialogVisible = false; // 关闭新增部门对话框
          this.getList(); // 重新获取部门列表数据
          this.getDeptVoList(); // 重新获取上级部门下拉列表数据
        }
      });
    },
    // 展示编辑部门对话框
    async showEditDeptDialog(id) {
      const { data: res } = await this.$api.deptInfo(id); // 发送 API 请求，根据部门 ID 获取部门信息
      if (res.code !== 200) { // 如果请求失败
        this.$message.error(res.message); // 显示错误消息
      } else {
        this.deptInfo = res.data; // 将获取到的部门信息存储到 deptInfo 中
        this.editDeptDialogVisible = true; // 显示编辑部门对话框
      }
    },
    // 监听编辑部门对话框关闭事件，重置表单
    editDeptDialogClosed() {
      this.$refs.editDeptFormRefForm.resetFields(); // 重置编辑部门表单中的所有字段
    },
    // 提交编辑后的部门数据
    editDept() {
      this.$refs.editDeptFormRefForm.validate(async valid => { // 验证表单数据
        if (!valid) return; // 如果验证未通过，终止操作
        const { data: res } = await this.$api.deptUpdate(this.deptInfo); // 发送 API 请求，提交编辑后的部门数据
        if (res.code !== 200) { // 如果请求失败
          this.$message.error(res.message); // 显示错误消息
        } else {
          this.editDeptDialogVisible = false; // 关闭编辑部门对话框
          this.getList(); // 重新获取部门列表数据
          this.$message.success('修改部门成功'); // 显示修改成功的提示消息
        }
      });
    },
    // 删除部门
    async handleDeptDelete(row) {
      const confirmResult = await this.$confirm('是否确认删除部门为"' + row.deptName + '"的数据项？', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).catch(err => err); // 显示确认对话框，并处理用户的确认或取消操作
      if (confirmResult !== 'confirm') { // 如果用户取消操作
        return this.$message.info('已取消删除'); // 显示取消操作的提示消息
      }
      const { data: res } = await this.$api.deleteDept(row.id); // 发送 API 请求，删除选中的部门
      if (res.code !== 200) { // 如果请求失败
        this.$message.error(res.message); // 显示错误消息
      } else {
        this.$message.success('删除成功'); // 显示删除成功的提示消息
        this.getList(); // 重新获取部门列表数据
      }
    }
  },
  // 组件创建时自动获取部门列表和部门下拉列表
  created() {
    this.getList(); // 调用 getList 方法，获取部门列表数据
    this.getDeptVoList(); // 调用 getDeptVoList 方法，获取上级部门下拉列表数据
  }
};

</script>