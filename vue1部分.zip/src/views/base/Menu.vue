<template>
  <el-card>
    <el-form :inline="true" :model="queryParams">
      <el-form-item prop="menuName" label="菜单名称">
        <el-input placeholder="请输入菜单名称" clearable size="mini" @keyup.enter.native="handleQuery"
          v-model="queryParams.menuName" />
      </el-form-item>
      <el-form-item prop="menuStatus" label="菜单状态">
        <el-select size="mini" placeholder="请选择菜单状态" v-model="queryParams.menuStatus">
          <el-option v-for="item in menuStatusList" :key="item.value" :label="item.label" :value="item.value" />
        </el-select>
      </el-form-item>
      <el-form-item>
        <el-button type="primary" icon="el-icon-search" size="mini" @click="handleQuery">搜索</el-button>
        <el-button type="primary" icon="el-icon-refresh" size="mini" @click="resetQuery">重置</el-button>
      </el-form-item>
    </el-form>
    <el-row :gutter="10" class="mb8">
      <el-col :span="1.5">
        <el-button type="primary" plain icon="el-icon-plus" size="mini"
          @click="addMenuDialogVisible = true">新增</el-button>
      </el-col>
      <el-col :span="1.5">
        <el-button type="info" plain icon="el-icon-sort" size="mini" @click="toggleExpandAll">展开/折叠</el-button>
      </el-col>
    </el-row>
    <el-table stripe :header-cell-style="{ background: '#eef1f6', color: '#606266' }" v-if="refreshTable"
      v-loading="loading" :data="menuList" row-key="id" :default-expand-all="isExpandAll"
      :tree-props="{ children: 'children' }">
      <el-table-column prop="menuName" label="菜单名称" />
      <el-table-column prop="icon" label="图标">
        <template slot-scope="scope">
          <i :class="scope.row.icon" />
        </template>
      </el-table-column>
      <el-table-column prop="sort" label="排序" />
      <el-table-column prop="value" label="权限标识" />
      <el-table-column prop="url" label="组件路径" />
      <el-table-column prop="menuType" label="菜单类型">
        <template slot-scope="scope">
          <el-tag v-if="scope.row.menuType === 1">目录</el-tag>
          <el-tag v-else-if="scope.row.menuType === 2" type="success">菜单</el-tag>
          <el-tag v-else-if="scope.row.menuType === 3" type="danger">按钮</el-tag>
        </template>
      </el-table-column>
      <el-table-column prop="menuStatus" label="状态">
        <template slot-scope="scope">
          <el-tag v-if="scope.row.menuStatus === 2" type="success">启用</el-tag>
          <el-tag v-else-if="scope.row.menuStatus === 1" type="danger">禁用</el-tag>
        </template>
      </el-table-column>
      <el-table-column label="创建时间" prop="createTime" />
      <el-table-column label="更多操作" class-name="small-padding fixed width">
        <template slot-scope="scope">
          <el-button size="mini" type="text" icon="el-icon-edit"
            @click="showEditMenuDialog(scope.row.id)">修改</el-button>
          <el-button size="mini" type="text" icon="el-icon-delete" @click="handleMenuDelete(scope.row)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>

    <!-- 新增菜单对话框   visible.sync 可以自动地将子组件的值变化同步到父组件中特定用法  -->  
    <el-dialog title="新增菜单" :visible.sync="addMenuDialogVisible" width="30%" @close="addMenuDialogClosed">
      <el-form :model="menuForm" :rules="addMenuFormRules" ref="addMenuFormRefForm" label-width="80px">
        <!-- rules是规则 后面定义的规则  ref固定格式reference this.$refs 来访问所有带有 ref 属性的元素或子组件   Vue 组件的 data 函数中，用于存储表单验证规则对象    -->
        <el-row>
          <el-col>
            <el-form-item label="菜单类型" prop="menuType">
              <el-radio-group v-model="menuForm.menuType">
                <el-radio :label="1">目录</el-radio>
                <el-radio :label="2">菜单</el-radio>
                <el-radio :label="3">按钮</el-radio>
              </el-radio-group>
            </el-form-item>
          </el-col>
          <el-col>
            <el-form-item size="mini" label="上级菜单" prop="parentId" v-if="menuForm.menuType != 1">
              <treeselect :options="treeList" placeholder="请选择上级菜单" v-model="menuForm.parentId" />
              <!-- 用于显示树形结构的下拉选择框。这个组件通常用来选择层级结构数据中的一个或多个项 -->
            </el-form-item>
          </el-col>
          <el-col>
            <el-form-item label="菜单图标" prop="icon" v-if="menuForm.menuType != 3">
              <el-select v-model="menuForm.icon">
                <el-option v-for="item in iconList" :key="item.value" :label="item.label" :value="item.value">
                  <i :class="item.value" style="font-size: 25px;" />
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col>
            <el-form-item label="菜单名称" prop="menuName">
              <el-input v-model="menuForm.menuName" placeholder="请输入菜单名称" />
            </el-form-item>
          </el-col>
          <el-col>
            <el-form-item label="显示排序" prop="sort">
              <el-input-number v-model="menuForm.sort" controls position="right" :min="0" />
            </el-form-item>
          </el-col>
          <el-col v-if="menuForm.menuType != 3">
            <el-form-item label="菜单url" prop="url">
              <el-input v-model="menuForm.url" placeholder="请输入菜单url" />
            </el-form-item>
          </el-col>
          <el-col>
            <el-form-item v-if="menuForm.menuType != 1" label="权限标识" prop="value">
              <el-input v-model="menuForm.value" placeholder="请输入权限标识" maxlength="50" />
            </el-form-item>
          </el-col>
          <el-col>
            <el-form-item v-if="menuForm.menuType != 3" label="显示状态" prop="menuStatus">
              <el-radio-group v-model="menuForm.menuStatus">
                <el-radio :label="1">停用</el-radio>
                <el-radio :label="2">启用</el-radio>
              </el-radio-group>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" @click="addMenu">确定</el-button>
        <el-button type="primary" @click="addMenuDialogVisible = false">取消</el-button>
      </div>
    </el-dialog>

    <!-- 修改菜单对话框 -->
    <el-dialog title="修改菜单" :visible.sync="editMenuDialogVisible" width="30%" @close="editMenuDialogClosed">
      <el-form :model="menuInfo" :rules="editMenuFormRules" ref="editMenuFormRefForm" label-width="80px">
        <el-row>
          <el-col>
            <el-form-item label="菜单类型" prop="menuType">
              <el-radio-group v-model="menuInfo.menuType">
                <el-radio :label="1">目录</el-radio>
                <el-radio :label="2">菜单</el-radio>
                <el-radio :label="3">按钮</el-radio>
              </el-radio-group>
            </el-form-item>
          </el-col>
          <el-col>
            <el-form-item size="mini" label="上级菜单" prop="parentId" v-if="menuInfo.menuType != 1">
              <treeselect :options="treeList" placeholder="请选择上级菜单" v-model="menuInfo.parentId" />
            </el-form-item>
          </el-col>
          <el-col>
            <el-form-item label="菜单图标" prop="icon" v-if="menuInfo.menuType != 3">
              <el-select v-model="menuInfo.icon">
                <el-option v-for="item in iconList" :key="item.value" :label="item.label" :value="item.value">
                  <i :class="item.value" style="font-size: 25px;" />
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col>
            <el-form-item label="菜单名称" prop="menuName">
              <el-input v-model="menuInfo.menuName" placeholder="请输入菜单名称" />
            </el-form-item>
          </el-col>
          <el-col>
            <el-form-item label="显示排序" prop="sort">
              <el-input-number v-model="menuInfo.sort" controls position="right" :min="0" />
            </el-form-item>
          </el-col>
          <el-col v-if="menuInfo.menuType != 3">
            <el-form-item label="菜单url" prop="url">
              <el-input v-model="menuInfo.url" placeholder="请输入菜单url" />
            </el-form-item>
          </el-col>
          <el-col>
            <el-form-item v-if="menuInfo.menuType != 1" label="权限标识" prop="value">
              <el-input v-model="menuInfo.value" placeholder="请输入权限标识" maxlength="50" />
            </el-form-item>
          </el-col>
          <el-col>
            <el-form-item v-if="menuInfo.menuType != 3" label="显示状态" prop="menuStatus">
              <el-radio-group v-model="menuInfo.menuStatus">
                <el-radio :label="1">停用</el-radio>
                <el-radio :label="2">启用</el-radio>
              </el-radio-group>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" @click="editMenu">确定</el-button>
        <el-button type="primary" @click="editMenuDialogVisible = false">取消</el-button>
      </div>
    </el-dialog>
  </el-card>
</template>

<script>
import Treeselect from "@riophae/vue-treeselect";  // 引入 Treeselect 组件用于树形选择框
import "@riophae/vue-treeselect/dist/vue-treeselect.css";  // 引入 Treeselect 组件的样式

export default {
  components: { Treeselect },  // 注册 Treeselect 组件
  data() {
    return {
      // 用于查询菜单的参数对象
      queryParams: {}, //表单数据
      // 菜单状态的选项列表
      menuStatusList: [
        { value: '2', label: '启用' },
        { value: '1', label: '停用' }
      ],
      loading: true,  // 控制表格加载状态的标志
      menuList: [],  // 存储菜单列表数据
      isExpandAll: false,  // 控制表格中菜单的展开/折叠状态
      refreshTable: true,  // 控制表格刷新状态的标志
      addMenuDialogVisible: false,  // 控制新增菜单对话框的显示/隐藏
      editMenuDialogVisible: false,  // 控制编辑菜单对话框的显示/隐藏
      menuForm: { menuStatus: 2 },  // 存储新增菜单表单的数据对象
      menuInfo: [],  // 存储编辑菜单表单的数据对象
      iconList: [  // 菜单图标的选项列表
        { value: 'el-icon-platform-eleme', label: 'el-icon-platform-eleme' },
        { value: 'el-icon-eleme', label: 'el-icon-eleme' },
        { value: 'el-icon-delete-solid', label: 'el-icon-delete-solid' },
        // ... 其他图标
      ],
      // 新增菜单表单的验证规则
      addMenuFormRules: {
        menuType: [{ required: true, message: "菜单类型不能为空", trigger: "blur" }],
        menuName: [{ required: true, message: "菜单名称不能为空", trigger: "blur" }],
        sort: [{ required: true, message: "菜单顺序不能为空", trigger: "blur" }],
        value: [{ required: true, message: "权限标识不能为空", trigger: "blur" }]
      },
      // 编辑菜单表单的验证规则
      editMenuFormRules: {
        menuType: [{ required: true, message: "菜单类型不能为空", trigger: "blur" }],
        menuName: [{ required: true, message: "菜单名称不能为空", trigger: "blur" }],
        sort: [{ required: true, message: "菜单顺序不能为空", trigger: "blur" }],
        value: [{ required: true, message: "权限标识不能为空", trigger: "blur" }]
      },
      treeList: []  // 存储上级菜单树形结构数据
    };
  },
  methods: {
    // 获取菜单列表数据
    async getMenuList() {
      this.loading = true;  // 开始加载，显示加载动画
      const { data: res } = await this.$api.queryMenuList(this.queryParams);  // 发起 API 请求获取菜单数据
      if (res.code !== 200) {
        this.$message.error(res.message);  // 如果请求失败，显示错误消息
      } else {
        this.menuList = this.$handleTree.handleTree(res.data, "id");  // 处理返回的菜单数据为树形结构
        this.loading = false;  // 加载完成，隐藏加载动画
      }
    },
    // 执行查询操作
    handleQuery() {
      this.getMenuList();  // 调用获取菜单列表方法，更新表格数据
    },
    // 重置查询条件
    resetQuery() {
      this.queryParams = {};  // 清空查询参数
      this.getMenuList();  // 重新获取菜单列表
      this.$message.success("重置成功");  // 显示重置成功的提示消息
    },
    // 切换表格展开/折叠状态
    toggleExpandAll() {
      this.refreshTable = false;  // 先将表格刷新状态置为 false
      this.isExpandAll = !this.isExpandAll;  // 切换展开/折叠状态
      this.$nextTick(() => {  // 在 DOM 更新完成后执行
        this.refreshTable = true;  // 重新启用表格刷新
      });
    },
    // 新增菜单对话框关闭时重置表单
    addMenuDialogClosed() {
      this.$refs.addMenuFormRefForm.resetFields();  // 重置新增菜单表单的所有字段
    },
    // 获取上级菜单的树形结构数据
    async getMenuVoList() {
      const { data: res } = await this.$api.querySysMenuVoList();  // 发起 API 请求获取菜单树形数据
      if (res.code !== 200) {
        this.$message.error(res.message);  // 如果请求失败，显示错误消息
      } else {
        this.treeList = this.$handleTree.handleTree(res.data, "id");  // 处理返回的数据为树形结构
      }
    },
    // 提交新增菜单表单
    addMenu() {
      this.$refs.addMenuFormRefForm.validate(async valid => {  
          //validate 是一个常用的 Vue 方法，通常在使用表单组件（如 el-form）时调用，用于触发表单字段的验证。
        if (!valid) return;  // 如果验证未通过，终止操作
        const { data: res } = await this.$api.addMenu(this.menuForm);  // 发起 API 请求提交新增菜单数据
        if (res.code !== 200) {
          this.$message.error(res.message);  // 如果提交失败，显示错误消息
        } else {
          this.$message.success("新增菜单成功");  // 显示新增成功消息
          this.addMenuDialogVisible = false;  // 关闭新增菜单对话框
          await this.getMenuList();  // 重新获取菜单列表
          await this.getMenuVoList();  // 重新获取菜单树形数据
        }
      });
    },
    // 编辑菜单对话框关闭时重置表单
    editMenuDialogClosed() {
      this.$refs.editMenuFormRefForm.resetFields();  // 重置编辑菜单表单的所有字段
    },
    // 显示编辑菜单对话框
    async showEditMenuDialog(id) {
      const { data: res } = await this.$api.menuInfo(id);  // 发起 API 请求获取菜单信息
      if (res.code !== 200) {
        this.$message.error(res.message);  // 如果请求失败，显示错误消息
      } else {
        this.menuInfo = res.data;  // 将获取到的菜单信息赋值给表单
        this.editMenuDialogVisible = true;  // 显示编辑菜单对话框
      }
    },
    // 提交编辑菜单表单
    editMenu() {
      this.$refs.editMenuFormRefForm.validate(async valid => {  // 验证表单数据
        if (!valid) return;  // 如果验证未通过，终止操作
        const { data: res } = await this.$api.menuUpdate(this.menuInfo);  // 发起 API 请求提交编辑后的菜单数据
        if (res.code !== 200) {
          this.$message.error(res.message);  // 如果提交失败，显示错误消息
        } else {
          this.editMenuDialogVisible = false;  // 关闭编辑菜单对话框
          await this.getMenuList();  // 重新获取菜单列表
          this.$message.success("修改菜单成功");  // 显示修改成功消息
        }
      });
    },
    // 删除菜单
    async handleMenuDelete(row) {
      const confirmResult = await this.$confirm('是否确认删除菜单为"' + row.menuName + '"的数据项？', '提示', {
        confirmButtonText: '确定',  // 确认按钮文本
        cancelButtonText: '取消',  // 取消按钮文本
        type: 'warning'  // 对话框类型，警告
      }).catch(err => err);  // 捕获取消操作的错误
      if (confirmResult !== 'confirm') {
        return this.$message.info('已取消删除');  // 如果用户取消删除，显示取消提示
      }
      const { data: res } = await this.$api.menuDelete(row.id);  // 发起 API 请求删除菜单
      if (res.code !== 200) {
        this.$message.error(res.message);  // 如果删除失败，显示错误消息
      } else {
        this.$message.success('删除成功');  // 显示删除成功消息
        await this.getMenuList();  // 重新获取菜单列表
      }
    }
  },
  created() {
    this.getMenuList();  // 组件创建时获取菜单列表数据
    this.getMenuVoList();  // 组件创建时获取菜单树形数据
  }
};
</script>



<style lang="less" scoped></style>